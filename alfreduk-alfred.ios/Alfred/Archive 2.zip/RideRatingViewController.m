

#import "RideRatingViewController.h"
#import <Parse/Parse.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import "HUD.h"

@interface RideRatingViewController ()



@end

@implementation RideRatingViewController
@synthesize starRatingView;

@synthesize rideRequest;

- (void)viewDidLoad {
    


    [super viewDidLoad];
    PFUser *ratedUser;
    if([[PFUser currentUser][@"UserMode"] boolValue]){
    
        //show driver info
       
                ratedUser =  self.rideRequest[@"driver"];
        
    
    }else{
        //show user info
        ratedUser = self.rideRequest[@"requestdBy"];
    }

    NSString * firstName = ratedUser[@"FirstName"];
    NSString *lastName = ratedUser[@"LastName"];
    
    self.nameLabel.text  = [NSString stringWithFormat:@"%@ %@",firstName, lastName];
    self.rateLabel.text = [NSString stringWithFormat:@"RATE %@ ON THIS RIDE", [firstName uppercaseString ] ];
    
    //set profile pic
    
    self.rideCostLabel.text = [NSString stringWithFormat:@"Ride cost: %4.2lf £",[self.rideRequest[@"ridePrice"] doubleValue]];
    
    
    NSString *profilePicUrl = ratedUser[@"ProfilePicUrl"];
    self.profilePicImageView.layer.cornerRadius = self.profilePicImageView.frame.size.width/2;
    self.profilePicImageView.layer.masksToBounds = YES;
    
    [self.profilePicImageView sd_setImageWithURL:[NSURL URLWithString:profilePicUrl] placeholderImage:[UIImage imageNamed:@"blanck profile"]];
    
    
    
                           
    self.rate1View.maximumValue = self.rate2View.maximumValue = self.rate3View.maximumValue = 5;
    self.rate1View.minimumValue = self.rate2View.minimumValue = self.rate3View.minimumValue = 1;
    self.rate1View.value = self.rate2View.value = self.rate3View.value = 1;
    

    starRatingView.maximumValue = 5;
    starRatingView.minimumValue = 1;
    starRatingView.value = 5.0;
    
    
    [starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
    rating = 1;

}

- (void)didChangeValue:(HCSStarRatingView *)sender {
    
    
    rating = sender.value;
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)rateAction:(id)sender {
    
   
    
    [self rateTheRide];
    

    
}

-(void)rateTheRide{
    
    [HUD showUIBlockingIndicatorWithText:@"Posting feedback ..."];
    bool isUser = [[PFUser currentUser][@"UserMode"] boolValue];
    PFObject *user;
    PFObject* ratingData;
    if(isUser) {
        
        //rate the driver
        
        
        user= self.rideRequest[@"driver"];
        ratingData = user[@"driverRating"];
        
    }else{
        user = self.rideRequest[@"requestedBy"];

        ratingData = user[@"userRating"];
    }
    
       ;
        double currentRating = [ ratingData[@"rating"] doubleValue];
        int rideCount = [ratingData[@"rideCount"] intValue];

        
        currentRating = currentRating * rideCount + rating;
        rideCount++;
        currentRating = currentRating/rideCount;
        ratingData[@"rideCount"] = [NSNumber numberWithInt:rideCount];
        ratingData[@"rating"] = [NSNumber numberWithDouble:currentRating];
    
        if(self.commentTextField.text.length > 0)
        {
            PFObject *ratingComment =[PFObject objectWithClassName:@"RatingComment"];
            ratingComment[@"user"] = user;
            ratingComment[@"author"] = [PFUser currentUser];
            
            ratingComment[@"comment"] = self.commentTextField.text;
            ratingComment[@"rideRequest"] = self.rideRequest.objectId ;
            [ratingComment saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                if(error){
                    [[[UIAlertView alloc] initWithTitle:nil message:@"Can't save rating data for user" delegate:nil cancelButtonTitle:@"Accept" otherButtonTitles:nil] show];
                    
                
                }else{
                    NSLog(@"Rating data saved sucessfully");
                }
            }];
        }
    
        [ratingData saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
            if(error){
                NSLog(error.localizedDescription);
            }
            [HUD hideUIBlockingIndicator];
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
        
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
