    //
//  DriverViewController.m
//  Alfred
//
//  Created by Arjun Busani on 25/02/15.
//  Modified by Miguel Carvajal on 23/08/2015
//  Copyright (c) 2015 A Ascendanet Sun. All rights reserved.
//

#import "DriverViewController.h"
#import "SWRevealViewController.h"
#import "RiderViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <Parse/Parse.h>
#import "RideSettingsViewController.h"

#import "DriverHeadViewController.h"

#import "CHDraggingCoordinator.h"
#import "CHDraggableView.h"
#import "CHDraggableView+Avatar.h"

#import "KLCPopup/KLCPopup.h"



@import MapKit;


@interface DriverViewController ()<SWRevealViewControllerDelegate, CHDraggingCoordinatorDelegate, DriverHeadDelegate>
{
    double myLatitude;
    double myLongitude;
    UIBarButtonItem *cancelButton;
    PFUser * user;
    PFObject *driverStatus;
    PFObject *activeRide;
    PFObject *driverLocation; //this is retrieved once from parse and used through the live cicle of the activity
    CLLocationCoordinate2D destinationCoord;
    CLLocationCoordinate2D driverCoord;
    BOOL rideConfigured;
    
    //handle the drawing of chat heads
    CHDraggingCoordinator *_draggingCoordinator;
    KLCPopup *popup;
    NSMutableArray *_rideRequests;
    PFObject* _lastRideRequest;
    NSMutableArray *_chatHeads;
    NSTimer *_mapCenterTimer ;
    DriverHeadViewController *vc;
 
    
}
@end

@implementation DriverViewController
@synthesize mapView,region;
@synthesize currentAddress,startRideButton;
@synthesize cancelButton,currentLocationLabel,locationManager,userCity,driverLatLoc,driverLongLoc,driverLocationTimer;
@synthesize rideRequestArray;
@synthesize requestRidePopupViewController,pickupAddress,dropoffAddress,pickupPlacemark,dropoffPlacemark;
@synthesize dropOffAddress,dropOffAnnotation,dropOffCoord;
@synthesize requestRideDecisionPopupViewController,userLat,userLong,routeDetails,pickUpCoord,destLat,destLong,isDriverAccepted,rideID;
@synthesize calucaltateDistanceTimer,driverDistanceTravelled,distanceCovered,driverStartLat,driverStartLong;
@synthesize userView,bottomLayoutConstrint;
@synthesize userProfilePic,userMobile,userName,userRating,userPhone;
@synthesize rideRatingViewController,messageBoardDict;
@synthesize messageBoardStartRideViewController,selectedUserDict,endMessageBoardButton;
@synthesize messageBoardUsersBGView;

@synthesize cancelRideButton,callButton,messageBoardUsersViewController,rideEndArray;

- (IBAction)centerInDriverLocation:(id)sender {
    
    [   self  centerOnUsersLocation:sender];
    
    
}

- (IBAction)searchAddress:(id)sender {
    
    NSLog(@"Search Address");
    
    
    
    [self performSegueWithIdentifier:@"SearchViewPush" sender:self];
    
}


//called when the dropoff button was touched to set destination



-(void)addChatHead:(int)rideRequestIndex{
    
    PFObject *rideRequest = [_rideRequests objectAtIndex:rideRequestIndex];
    
    UIImageView* imgView =[[UIImageView alloc] init];
    [imgView sd_setImageWithURL:rideRequest[@"requestedBy"][@"ProfilePicUrl"] placeholderImage:[UIImage imageNamed:@"profile_pic_teja"]];

    
    
    CHDraggableView *draggableView = [CHDraggableView draggableViewWithImage:imgView.image];
    
    draggableView.tag = rideRequestIndex;
    
    [draggableView snapViewCenterToPoint: CGPointMake(self.view.layer.frame.size.width,100)  edge:0];
    draggableView.delegate = _draggingCoordinator;
    [self.navigationController.view addSubview:draggableView];
    [_chatHeads addObject:draggableView];
    
}


-(void)setupChatHeads{
   
    
    
    _draggingCoordinator = [[CHDraggingCoordinator alloc] initWithWindow:[[UIApplication sharedApplication] keyWindow] draggableViewBounds:self.view.bounds];
    _draggingCoordinator.delegate = self;
    _draggingCoordinator.snappingEdge = CHSnappingEdgeBoth;
   
  
}

- (void)draggingCoordinator:(CHDraggingCoordinator *)coordinator presentViewForDraggableView:(CHDraggableView*)view
{
    
    //get chat head index
    int index =    [_chatHeads indexOfObject:view];
    PFObject *rideRequest = _rideRequests[index];
    
    
    
    
    
    NSLog(@"Detected");
    
    // Show in popup
    KLCPopupLayout layout = KLCPopupLayoutMake(KLCPopupHorizontalLayoutCenter,KLCPopupVerticalLayoutBottom);
    
    vc = [[DriverHeadViewController alloc]initWithNibName:@"DriverHeadViewController" bundle:nil];
    
    [vc setRideRequest:rideRequest];
    vc.delegate = self;
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    CGRect viewFrame = vc.view.frame;
    viewFrame.size.width = screenWidth;
    vc.view.frame =  viewFrame;
        

    popup = [KLCPopup popupWithContentView:vc.view
                                  showType:KLCPopupShowTypeSlideInFromBottom
                               dismissType:KLCPopupDismissTypeSlideOutToBottom
                                  maskType:KLCPopupMaskTypeDimmed
                  dismissOnBackgroundTouch:YES
                     dismissOnContentTouch:NO];
    [popup showWithLayout:layout];
    
    
}

-(void)draggingCoordinator:(CHDraggingCoordinator *)coordinator dismissViewForDraggableView:(CHDraggableView*)view
{
    NSLog(@"Detected");
}


- (void) didRequestForSearchResult:(NSNotification *)notification
{
    
    rideConfigured = NO;
    
    self.navigationItem.rightBarButtonItem =  cancelButton;
    
    NSLog(@"Search finished");
    CLPlacemark *placemark =  [notification object];
    
    self.locationSearchButton.enabled = NO;
    
    startRideButton.hidden = NO;
    destinationCoord = placemark.location.coordinate;
    
    dropOffAnnotation = [[DropoffAnnotation alloc] initiWithTitle:@"Destination" Location:destinationCoord];
    
    [mapView addAnnotation:dropOffAnnotation];
    [_dropOffButton setHidden:YES];
    [_dropOffPinImage setHidden:YES];
    
    // get driver origin
    driverCoord = [[mapView userLocation] coordinate];
    
    
    [startRideButton setTitle:@"ADVERTISE YOUR JOURNEY" forState:UIControlEventTouchUpInside];
    [startRideButton removeTarget:self action:@selector(endRide:) forControlEvents:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlStateNormal];
    
    [startRideButton addTarget:self action:@selector(startRideButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    
    
    destinationCoord = [mapView centerCoordinate];
    
    driverStatus[@"destination"] = [PFGeoPoint geoPointWithLatitude:destinationCoord.latitude longitude:destinationCoord.longitude];
    
    driverStatus[@"active"] = @YES;
    [driverStatus saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        if(succeeded){
            NSLog(@"Saved driver destination in parse");
            
        }
    }];
    
    
    
    
    // trace route from origin to destination
    
    
    [self traceRouteWithStartingCoordinates:pickUpCoord end:destinationCoord];
    
    
    
    
    
}


- (IBAction)setDestinationTouchedUpInside:(id)sender {
    
    
    rideConfigured = NO;
    self.navigationItem.rightBarButtonItem =  cancelButton;
    
    //TODO: set driver destination
    
    startRideButton.hidden = NO;
    
    [startRideButton setTitle:@"ADVERTISE YOUR JOURNEY" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(endRide:) forControlEvents:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlStateNormal];
    
    [startRideButton addTarget:self action:@selector(startRideButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    
    self.locationSearchButton.enabled = NO;
    
    
    destinationCoord = [mapView centerCoordinate];
    
    driverStatus[@"destination"] = [PFGeoPoint geoPointWithLatitude:destinationCoord.latitude longitude:destinationCoord.longitude];
    if(currentAddress.length == 0 || currentAddress.length == 0){
        driverStatus[@"destinationAddress"] = @"Undetermined";
    }else{
        driverStatus[@"destinationAddress"] = currentAddress;
    }
    
    
    dropOffAnnotation = [[DropoffAnnotation alloc] initiWithTitle:@"Your Destination" Location:destinationCoord];
    
    [mapView addAnnotation:dropOffAnnotation];
    [_dropOffButton setHidden:YES];
    [_dropOffPinImage setHidden:YES];
    
    // get driver origin
    driverCoord = [[mapView userLocation] coordinate];
    
    
    // trace route from origin to destination
    
    
    [self traceRouteWithStartingCoordinates:driverCoord end:destinationCoord];
    
    
    
    
}

-(void)traceRouteWithStartingCoordinates: (CLLocationCoordinate2D)startCoordinate end:(CLLocationCoordinate2D) endCoordinate {
    
    
    
    MKDirectionsRequest *directionsRequest = [[MKDirectionsRequest alloc] init];
    
    MKPlacemark *dropPlacemark = [[MKPlacemark alloc] initWithCoordinate: startCoordinate addressDictionary:nil];
    MKPlacemark *pickPlacemark = [[MKPlacemark alloc] initWithCoordinate: endCoordinate addressDictionary:nil];
    
    [directionsRequest setSource:[[MKMapItem alloc] initWithPlacemark:pickPlacemark]];
    [directionsRequest setDestination:[[MKMapItem alloc] initWithPlacemark:dropPlacemark]];
    directionsRequest.transportType = MKDirectionsTransportTypeAutomobile;
    
    MKDirections *directions = [[MKDirections alloc] initWithRequest:directionsRequest];
    
    [HUD showUIBlockingIndicatorWithText:@"Routing.."];
    
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        NSLog(@"Calculating directions completed");
        
        if (error) {
            
            NSLog(@"Calculation directions error\nError %@", error.description);
            [[            [UIAlertView alloc]initWithTitle:@"Error!" message:@"Route services is not available right now" delegate:nil cancelButtonTitle:@"Accept" otherButtonTitles:nil, nil] show ];
        }
        else{
            assert(response);
            if(routeDetails){
                
                [self.mapView removeOverlay:routeDetails.polyline];
            }
            
            routeDetails = response.routes.lastObject;
            
            [self.mapView addOverlay:routeDetails.polyline];
            
            [self showRouteOnMap];
            
        }
        
        [HUD hideUIBlockingIndicator];
    }];
    
}

-(void)configureNavigationBar {
    
    [self.navigationController.navigationBar setTranslucent:NO];
   
    self.navigationItem.title = @"DRIVER MAP";
    
}

- (void)viewDidLoad {
    
    //ui configuration
    
    [self configureView];
    

    
    // user status configuration
    
    
    rideConfigured = NO;
    isItRetrieval = NO;
    _lastRideRequest = nil;
    
    
    //load the driver status classs form parse
    
    [self checkForUserStatus];
    
    //this is for what?
    selectedUserDict = [[NSDictionary alloc] init];
    
    driverStatus = nil;
    [self loadDriverStatus];
    
    driverLocation = nil;
    
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        [self.locationManager startUpdatingLocation];
        mapView.showsUserLocation = YES;
        mapView.userTrackingMode=YES;
        
        CLLocationCoordinate2D coord = mapView.userLocation.location.coordinate;
        MKCoordinateRegion intialRegion = MKCoordinateRegionMakeWithDistance(coord, 1000.0, 1000.0);
        [mapView setRegion:intialRegion animated:YES];
        
    }
    
    
    currentAddress = @"Undeterminated";
    
    
    
    
    
}

-(void )configureView{
    
    
    
    [super viewDidLoad];
    
    self.userView.layer.cornerRadius = 0.5;
    self.userView.layer.shadowOpacity = 0.8;
    self.userView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    [messageBoardUsersBGView setHidden:YES];
    [endMessageBoardButton setHidden:YES];
    [userView setHidden:YES];
  

    [self watchForNotifications];
    // set drawer button
    UIImage *menuImage = [[UIImage imageNamed:@"menu"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIBarButtonItem *revealButtonItem = [[UIBarButtonItem alloc] initWithImage:menuImage
                                                                         style:UIBarButtonItemStylePlain target:self action:@selector(revealToggle:)];
    
    
    
    UIImage *blackArrowImage = [[UIImage imageNamed:@"arrow black"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    
    
    
    [ cancelRideButton addTarget:self action:@selector(cancelRide:) forControlEvents:UIControlEventTouchUpInside];
    
    cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"CANCEL" style:UIBarButtonItemStylePlain target:self action:@selector(cancelDropoff:)];
    
    
    
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    mapView.delegate = self;
    [mapView setRotateEnabled:NO];
    
    startRideButton.hidden = YES;
    
    SWRevealViewController *revealViewController = self.revealViewController;
    self.navigationItem.leftBarButtonItem = revealButtonItem;
    
    
    //hidden at the begining
    self.navigationItem.rightBarButtonItem = nil;


    [self configureNavigationBar];
    
    
    
    driverLocationTimer=  [NSTimer scheduledTimerWithTimeInterval:4.0
                                                           target:self
                                                         selector:@selector(updateDriverLocation:)
                                                         userInfo:nil
                                                          repeats:YES];
    _mapCenterTimer = [NSTimer scheduledTimerWithTimeInterval: 3.0 target: self
                                   selector: @selector(updateLocationBarOnUserLocation) userInfo: nil repeats: YES];
    
    
    self.locationLabel.text = @"Updating Location..";
    currentLocationLabel.text = @"Updating Location..";
    
    _chatHeads = [[NSMutableArray alloc]init];
    _rideRequests =[[NSMutableArray alloc] init];
    
    if ( revealViewController ){
        [self.view addGestureRecognizer:revealViewController.panGestureRecognizer];
        
        
        [self.navigationItem.leftBarButtonItem setTarget:self.revealViewController];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    [self setupChatHeads];
    
}



-(void)loadDriverStatus{
    
    NSLog(@"Loading driver status");
    
    PFQuery *query = [PFQuery queryWithClassName:@"DriverStatus"];
    [query whereKey:@"user" equalTo:[PFUser currentUser]];
    [query includeKey:@"user"];
    
    [query getFirstObjectInBackgroundWithBlock:^(PFObject * _Nullable object, NSError * _Nullable error) {
        if(!error){
            driverStatus = object;
            NSString* userId =[[PFUser currentUser]objectId];
            assert( [ [driverStatus[@"user"] objectId] isEqualToString:userId]);
            NSLog(@"Loaded driver status");
        }else{
        
            NSLog(@"Driver status not loadded");
            //cant continue
        }
    }];
    
    
    
    
    
}


-(void)cancelRide:(id)sender{
    
    
    PFQuery *userQuery =[PFInstallation query];
    [ userQuery whereKey:@"user" equalTo: user];
    
    PFPush *push = [[PFPush alloc] init];
    
    [push setQuery:userQuery ];
    
    NSDictionary *data = @{
                           @"alert" : @"Your ride was canceled by the driver.",
                           @"rid" : rideID,
                           @"key" : @"RIDE_CANCELLED_BY_DRIVER",
                           @"badge": @"Increment"
                           };
    
    [push setData:data];
    
    
    [push sendPushInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        if(succeeded){
            NSLog(@"Push for canceling request succeeded");
            activeRide[@"canceledByDriver"] = @YES;
            [activeRide saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                NSLog(@"Ride canceled by driver");
            }];
            
        }
    }];
    
    
    [self.mapView removeOverlay:routeDetails.polyline];
    
    [mapView removeAnnotation:dropOffAnnotation];
    
    
    [startRideButton removeTarget:self action:@selector(endRide:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton setHidden:YES];
    
    bottomLayoutConstrint.constant = 10;
    [userView setHidden:YES];
    for(CHDraggableView *view in _chatHeads){
        [view removeFromSuperview];
    }
    
    [_chatHeads removeAllObjects];
    for(PFObject *ride in _rideRequests){
        ride[@"canceledByDriver"] = @YES;
        [ride saveEventually];
    }
    [_rideRequests removeAllObjects];
    
    isDriverAccepted = NO;
    
    
}

-(void)cancelDropoff:(id)sender{
    if([driverStatus[@"inride"] boolValue] ){
        [self cancelRide:nil];
    }
    
    //remove anotation
    self.locationSearchButton.enabled = YES;
    
    //remove route
    [self.mapView removeOverlay:routeDetails.polyline];
    
    isDriverAccepted = NO;
    
    startRideButton.hidden = YES;
    
    //remove all annotations
    [self.mapView removeAnnotations: self.mapView.annotations];
    
    [_dropOffButton setHidden:NO];
    [_dropOffPinImage setHidden:NO];
    
    self.navigationItem.rightBarButtonItem = nil;
    
    driverStatus[@"active"] = @NO;
    driverStatus[@"inride"] = @NO;
    [driverStatus saveInBackground];
    self.startRideButton.hidden = YES;
    [self.startRideButton removeTarget:self action:@selector(startRideButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    [self.startRideButton removeTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlEventTouchUpInside];
    [self.startRideButton removeTarget:self action:@selector(endRide:) forControlEvents:UIControlEventTouchUpInside];
    
    
    //[self cancelRide:nil];
    
    
}

-(void)checkForMissingDriverRequests{
    
    PFQuery * query = [PFQuery queryWithClassName:@"RideRequest"];
    [query whereKey:@"driver" equalTo:[PFUser currentUser]];
    [query whereKey:@"finished" notEqualTo:@YES];
    [query whereKey:@"canceled" notEqualTo:@YES];
    [query whereKey:@"canceledByDriver" notEqualTo:@YES];
    [query includeKey:@"requestedBy"];
    
    
    [query findObjectsInBackgroundWithBlock:^(NSArray * _Nullable objects, NSError * _Nullable error) {
        if(!error  && [objects count] > 0){
            
            [self   processRideRequest: [objects firstObject] ];
            
            //only interested on last one
            return;
            
        }
    }];
}

-(void)viewDidAppear:(BOOL)animated{
    //[self checkForMissingDriverRequests];
}




-(void)watchForNotifications{
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForStoppingAllMappingServices:) name:@"didRequestForStoppingAllMappingServices" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForStoppingAllMappingServices:) name:@"didRequestForStoppingAllMappingServices" object:nil];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(driverDecisionTaken:) name:@"driverDecisionTaken" object:nil];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideRequest:) name:@"didRequestForRideRequest" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideRequest:) name:@"didRequestForStartTheMessageBoardRide" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideAcceptedForDriver:) name:@"didRequestForRideAcceptedForDriver" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideAcceptedByAnotherDriver:) name:@"didRequestForRideAcceptedByAnotherDriver" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideDecisionCloseView:) name:@"didRequestForRideDecisionCloseView" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideRequestCancel:) name:@"didRequestForRideRequestCancel" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForRideEnd:) name:@"didRequestForRideEnd" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForOpenRatinView:) name:@"didRequestForOpenRatinView" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForMessageBoardStartRide:) name:@"didRequestForMessageBoardStartRide" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForMessageBoardStartAccepted:) name:@"didRequestForMessageBoardStartAccepted" object:nil];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForUserSelected:) name:@"didRequestForUserSelected" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForMessageBoardRideEnded:) name:@"didRequestForMessageBoardRideEnded" object:nil];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForSearchResult:) name:@"didRequestForSearchResult" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didConfigureRide) name:@"didConfigureRide" object:nil];
    
}


//called when the driver saves the data properly on the settigns view
-(void)didConfigureRide{
    
    rideConfigured = YES;
    

}


#pragma mark - Ride Request



/*
 * Called when a new ride requesta arrive, to handle it and take the pertinent
 * actiosn
 */

-(void)processRideRequest:(PFObject *) rideRequest{
    
    
    //this is wrong, there should not be only one rideid,
    //the driver can have more than one riderequest at the time
    // multiple bubbles
    
    rideID = rideRequest.objectId;
    
    _lastRideRequest = rideRequest;
    
    NSLog(@"request id%@", rideID);
    
    //get the request data from server
    //and prompt for accepting or rejecting it
    
    
    
    
    NSString* originLatitude = rideRequest[@"pickupLat"];
    NSString* originLongitude = rideRequest[@"pickupLong"];
    
    userLat = [originLatitude doubleValue];
    userLong = [originLongitude doubleValue];
    
    NSString* destinationLatitude = rideRequest[@"dropoffLat"];
    NSString* destinationLongitude = rideRequest[@"dropoffLong"];
    
    destLat = [destinationLatitude doubleValue];
    destLong = [destinationLongitude doubleValue];
    
    int seats =[rideRequest[@"seats"] intValue];
    
    user = rideRequest[@"requestedBy"];
    NSAssert(user!= nil, @"User that requested the ride can't be nil");
    NSString* userId = user.objectId;
    
    //NSString* originalAddress = responseObject[@"originAddress"];
    //NSString* dropAddress =responseObject[@"dropAddress"];
    
    NSString* riderName = user[@"FullName"];
    
    
    userPhone = user[@"Phone"];

    
    PFObject *ratingData = user[@"userRating"];
    
    

    
    NSString* userPic =user[@"ProfilePicURL"];
    
    {
    
        requestRidePopupViewController = [[RequestRidePopupViewController alloc] initWithNibName:@"RequestRidePopupViewController" bundle:nil];
        
        requestRidePopupViewController.pickupAddress = rideRequest[@"pickupAddress"];
        // originalAddress;
        
        requestRidePopupViewController.rideRequest = rideRequest;
        requestRidePopupViewController.dropoffAddress = rideRequest[@"dropoffAddress"]; //dropAddress;
        requestRidePopupViewController.mobile = userPhone;
        requestRidePopupViewController.rating = ratingData[@"rating"];
        requestRidePopupViewController.requestId = rideID;
        
        requestRidePopupViewController.riderName = riderName;
        requestRidePopupViewController.userId = user.objectId;
        
        requestRidePopupViewController.seats = seats;
        requestRidePopupViewController.pricePerSeat = [driverStatus[@"pricePerSeat"] doubleValue];
        requestRidePopupViewController.requestRideId = rideID;
        requestRidePopupViewController.isActive = isDriverAccepted;
        
        requestRidePopupViewController.driverCity = userCity;
        requestRidePopupViewController.userPic = userPic;
    
    }
    
    self.userName.text = riderName;
    self.userMobile.text = userPhone;
    self.ratingView.value = [ratingData[@"rating"] doubleValue];
    
    
    
    [requestRidePopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:requestRidePopupViewController animated:YES completion:nil];
    
    
    
}


-(void)didRequestForRideRequest:(NSNotification *)notification
{
    
    
    //isDriverAccepted
    
    
    NSString* requestId  = [notification object];
    
    if(driverStatus == nil){
        
        PFQuery * query = [PFQuery queryWithClassName:@"DriverStatus"];
        [query whereKey:@"user" equalTo:[[PFUser currentUser] objectId]];
        [query getFirstObjectInBackgroundWithBlock:^(PFObject * _Nullable object, NSError * _Nullable error) {
            if(error){
                
                NSLog(@"Somethig wrong happend, alert user");
                
            }else{
                [self didRequestForRideRequest:notification];
            
            }
            
        }];
        
    }
    if([driverStatus[@"active"] boolValue]){
        
    
        
        PFQuery * query =  [PFQuery queryWithClassName:@"RideRequest"];
        [query whereKey:@"canceled" notEqualTo:@YES];
        [query whereKey:@"canceledByDriver" notEqualTo:@YES];
        [query includeKey:@"requestedBy"];
        [query includeKey:@"requestedBy.userRating"];
        
        //get the ride request object from Parse
        [query getObjectInBackgroundWithId:requestId block:^(PFObject * _Nullable object, NSError * _Nullable error) {
            if(error ==  NULL ){
                NSLog(@"Processing ride request with id");
                NSLog(object.objectId);
                
                [self processRideRequest:object];
            }else{
                
                NSLog(@"Can get ride request properly");
                [[  [UIAlertView alloc] initWithTitle:@"Error" message:error.localizedDescription delegate:nil cancelButtonTitle:@"Accept" otherButtonTitles:nil] show];
            
            }
        }];
    
    }else{
        //this would happend because driver canceled ride or some cached results
        //for now just silently ignore it but later on
        // should send push with cancel from driver
    }

    
}


#pragma mark - Activate Driver Mode


-(void)didRequestForMessageBoardStartRide:(NSNotification *)notification{
    
    NSLog(@"Notification: %@", notification);
    
    messageBoardDict = [notification object];
    
    double driverMessageLat = mapView.userLocation.location.coordinate.latitude;
    double driverMessageLong = mapView.userLocation.location.coordinate.longitude;
    
    
    NSString* latNow = [NSString stringWithFormat:@"%f",driverMessageLat];
    NSString* longNow = [NSString stringWithFormat:@"%f",driverMessageLong];
    
    messageBoardStartRideViewController = [[MessageBoardStartRideViewController alloc] initWithNibName:@"MessageBoardStartRideViewController" bundle:nil];
    
    [messageBoardStartRideViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    messageBoardStartRideViewController.messageBoardDict = messageBoardDict;
    messageBoardStartRideViewController.latNow = latNow;
    messageBoardStartRideViewController.longNow = longNow;
    
    [self presentViewController:messageBoardStartRideViewController animated:YES completion:nil];
}


-(void)didRequestForMessageBoardStartAccepted:(NSNotification *)notification
{
    
    isDriverAccepted = YES;
    [self checkForUserStatus];
    
}


-(void)activateMessageDriveMode:(NSDictionary*)messageDict{
    
    NSArray* usersArray = messageDict[@"driverMessageRequests"];
    if ([usersArray count]>0) {
        selectedUserDict = usersArray[0];
        self.userName.text = selectedUserDict[@"userName"];
        self.userMobile.text = [NSString stringWithFormat:@"Cell: %@",selectedUserDict[@"userMobile"]];
        
        userPhone =selectedUserDict[@"userMobile"];
        
        double driverRatingDouble = [[selectedUserDict objectForKey:@"userRating"] doubleValue];
        NSString* driverRating =[NSString stringWithFormat:@"Rating: %.2f",driverRatingDouble];
        
        self.userRating.text =driverRating;
        NSString* userProfilePics =selectedUserDict[@"userProfilePic"];
        
        
        
        if (![userProfilePics isKindOfClass:[NSNull class]]) {
            
            
            [self.userProfilePic sd_setImageWithURL:[NSURL URLWithString:userProfilePics] placeholderImage:[UIImage imageNamed:@"blank profile"]];
        }
        
        [self.userProfilePic setContentMode:UIViewContentModeScaleAspectFill];
        
        self.userProfilePic.layer.cornerRadius = self.userProfilePic.frame.size.height /2;
        self.userProfilePic.layer.masksToBounds = YES;
        self.userProfilePic.layer.borderWidth = 0;
        
        
        
    }
    
    [endMessageBoardButton setHidden:NO];
    [endMessageBoardButton addTarget:self action:@selector(endMessageBoard:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [startRideButton setTitle:@"NAVIGATE" forState:UIControlStateNormal];
    [startRideButton setHidden:NO];
    [startRideButton addTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
    
    bottomLayoutConstrint.constant = 80;
    
    
    [userView setHidden:NO];
    
    [messageBoardUsersBGView setHidden:NO];
    [self addMessageBoardUsers];
    
    [cancelRideButton setTitle:@"NAVIGATE" forState:UIControlStateNormal];
    [cancelRideButton addTarget:self action:@selector(navigateToMessageBoard:) forControlEvents:UIControlEventTouchUpInside];
    
    
}

-(void)addMessageBoardUsers{
    
    NSArray* usersArray = messageBoardDict[@"driverMessageRequests"];
    
    NSString* userLats;
    NSString* userLongs;
    NSString* userID;
    UserAnnotation *userAnnotations;
    CLLocationCoordinate2D userCoordinates;
    CLLocationDegrees latDeg;
    CLLocationDegrees longDeg;
    double latDouble;
    double longDouble;
    NSString *name = @"Alfred User";
    
    
    for (NSDictionary* userDict in usersArray) {
        userLats = userDict[@"originLatitude"];
        userLongs = userDict[@"originLongitude"];
        
        
        
        latDouble = [userLats doubleValue];
        longDouble = [userLongs doubleValue];
        
        latDeg = latDouble;
        longDeg =longDouble;
        
        // NSLog(@"%f",latDeg);
        // NSLog(@"%f",longDeg);
        
        
        userID = [userDict objectForKey:@"userId"];
        userCoordinates = CLLocationCoordinate2DMake(latDeg, longDeg);
        
        userAnnotations = [[UserAnnotation alloc] initiWithTitle:name Location:userCoordinates];
        
        [mapView addAnnotation:userAnnotations];
        
        
        
    }
    
    
}





-(void)didRequestForRideDecisionCloseView:(NSNotification *)notification
{
    NSArray *boolDecision = [notification object];
    isDriverAccepted = [[boolDecision objectAtIndex:0] boolValue];
    
    if (isDriverAccepted) {
        
        
        // [startRideButton setTitle:@"NAVIGATE" forState:UIControlStateNormal];
        // [startRideButton setHidden:NO];
        // [startRideButton addTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
        
        // bottomLayoutConstrint.constant = 80;
        // [userView setHidden:NO];
        
        
        
        //[self requestRouteToUser];
        
        
    }
    
    
}


#pragma mark - Driver Mode Helper Methods

-(void)rideRequestDecisonMade:(NSString*)message{
    
    requestRideDecisionPopupViewController = [[RideRequestDecisionViewController alloc] initWithNibName:@"RideRequestDecisionViewController" bundle:nil];
    
    requestRideDecisionPopupViewController.decision = message;
    requestRideDecisionPopupViewController.isAccepted = YES;
    [requestRideDecisionPopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:requestRideDecisionPopupViewController animated:YES completion:nil];
    
    
    
}



-(void)addFirstNavPath:(id)sender{
    
    [self.mapView removeOverlay:routeDetails.polyline];
    [mapView removeAnnotation:dropOffAnnotation];
    
    NSString* originLatitude =selectedUserDict[@"originLatitude"];
    NSString* originLongitude =selectedUserDict[@"originLongitude"];
    
    userLat = [originLatitude doubleValue];
    userLong = [originLongitude doubleValue];
    
    [self requestRouteToUser];
    [startRideButton removeTarget:self action:@selector(startRide:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton removeTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton addTarget:self action:@selector(navigateToMessageBoardUser:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)navigateToMessageBoardUser:(id)sender{
    
    
    
    BOOL googleInstalled = [CMMapLauncher isMapAppInstalled:CMMapAppGoogleMaps];
    if (googleInstalled) {
        [CMMapLauncher launchMapApp:CMMapAppGoogleMaps
                    forDirectionsTo:[CMMapPoint mapPointWithName:dropoffAddress
                                                      coordinate:dropOffCoord]];
    }
    
    
}




- (IBAction)messageBoardUsers:(id)sender {
    
    NSArray* usersArray = messageBoardDict[@"driverMessageRequests"];
    
    
    NSString* requestRideId =messageBoardDict[@"requestRideId"];
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setObject:requestRideId forKey:@"requestRideId"];
    
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    double driverMessageLat = mapView.userLocation.location.coordinate.latitude;
    double driverMessageLong = mapView.userLocation.location.coordinate.longitude;
    
    
    NSString* latNow = [NSString stringWithFormat:@"%f",driverMessageLat];
    NSString* longNow = [NSString stringWithFormat:@"%f",driverMessageLong];
    
    
    
    messageBoardUsersViewController = [[MessageBoardUsersViewController alloc] initWithNibName:@"MessageBoardUsersViewController" bundle:nil];
    
    [messageBoardUsersViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    
    messageBoardUsersViewController.usersArray = usersArray;
    messageBoardUsersViewController.latNow = latNow;
    messageBoardUsersViewController.longNow = longNow;
    messageBoardUsersViewController.requestRideId = requestRideId;
    
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:messageBoardUsersViewController animated:YES completion:nil];
    
}

-(void)navigateToMessageBoard:(id)sender{
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@""
                                                             delegate:self
                                                    cancelButtonTitle:nil
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:@"Navigate to User", @"Navigate to Destination", nil];
    
    actionSheet.tag = 100;
    [actionSheet showInView:self.view];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (actionSheet.tag == 100) {
        if (buttonIndex == 0) {
            [self.mapView removeOverlay:routeDetails.polyline];
            [mapView removeAnnotation:dropOffAnnotation];
            
            NSString* originLatitude =selectedUserDict[@"originLatitude"];
            NSString* originLongitude =selectedUserDict[@"originLongitude"];
            
            userLat = [originLatitude doubleValue];
            userLong = [originLongitude doubleValue];
            [startRideButton removeTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
            [startRideButton addTarget:self action:@selector(navigateToMessageBoardUser:) forControlEvents:UIControlEventTouchUpInside];
            
            [self requestRouteToUser];
            
        }
        else if (buttonIndex ==1){
            [self.mapView removeOverlay:routeDetails.polyline];
            [mapView removeAnnotation:dropOffAnnotation];
            
            NSString* originLatitude =selectedUserDict[@"destinationLatitude"];
            NSString* originLongitude =selectedUserDict[@"destinationLongitude"];
            
            userLat = [originLatitude doubleValue];
            userLong = [originLongitude doubleValue];
            [startRideButton removeTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
            [startRideButton addTarget:self action:@selector(navigateToMessageBoardUser:) forControlEvents:UIControlEventTouchUpInside];
            
            [self requestRouteToUser];
            
            
        }
        
    }
    
    
    
}


-(void)didRequestForUserSelected:(NSNotification *)notification
{
    selectedUserDict = [notification object];
    
    NSLog(@"Selected Users: %@",selectedUserDict);
    
    self.userName.text = selectedUserDict[@"userName"];
    self.userMobile.text = [NSString stringWithFormat:@"Cell: %@",selectedUserDict[@"userMobile"]];
    userPhone =selectedUserDict[@"userMobile"];
    
    double driverRatingDouble = [[selectedUserDict objectForKey:@"userRating"] doubleValue];
    NSString* driverRating =[NSString stringWithFormat:@"Rating: %.2f", driverRatingDouble];
    
    self.userRating.text  =driverRating;
    
    NSString* userProfilePics =selectedUserDict[@"userProfilePic"];
    
    
    
    if (![userProfilePics isKindOfClass:[NSNull class]]) {
        
        
        [self.userProfilePic sd_setImageWithURL:[NSURL URLWithString:userProfilePics] placeholderImage:[UIImage imageNamed:@"blank profile"]];
    }
    
    [self.userProfilePic setContentMode:UIViewContentModeScaleAspectFill];
    
    self.userProfilePic.layer.cornerRadius = self.userProfilePic.frame.size.height /2;
    self.userProfilePic.layer.masksToBounds = YES;
    self.userProfilePic.layer.borderWidth = 0;
    
    
    
    
    [self.mapView removeOverlay:routeDetails.polyline];
    [mapView removeAnnotation:dropOffAnnotation];
    
    NSString* destinationLatitude =selectedUserDict[@"destinationLatitude"];
    NSString* destinationLongitude =selectedUserDict[@"destinationLongitude"];
    
    userLat = [destinationLatitude doubleValue];
    userLong = [destinationLongitude doubleValue];
    
    double originLatitude =[selectedUserDict[@"originLatitude"] doubleValue];
    double originLongitude =[selectedUserDict[@"originLongitude"] doubleValue];
    
    [self routedAnnotationsForUserSelected:originLatitude long:originLongitude];
}


#pragma mark - Remove Driver Mode


-(void)removeMessageBoardUsers{
    
    for (id annotation in [mapView annotations])
    {
        [mapView removeAnnotation:annotation];
        
    }
    
    
}

-(void)endMessageBoard:(id)sender{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Confirm"
                                                                             message:@"Confirm you want to end the Message Board Ride. Please drop all users before ending ride."
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:NSLocalizedString(@"Cancel", @"Cancel action")
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction *action)
                                   {
                                       NSLog(@"Cancel action");
                                   }];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"End Ride", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   [self confirmedEndRideForMessageBoard];
                                   
                                   
                               }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
    
    
}

//called after popup option was selected
-(void)driverDecisionTaken:(NSNotification *)notification
{
    bool desicion = [[notification object] boolValue];
    
    if(desicion == YES){
        
        assert(_lastRideRequest != nil);
        [_rideRequests addObject:_lastRideRequest];

        
        isDriverAccepted = YES;
        //once the driver accepts the ride request for the user it status is in ride
        
        driverStatus[@"inride"] = @YES;
        
        //the number of seats is reduced now
        driverStatus[@"numberOfSeats"] = [NSNumber numberWithInt:( [driverStatus[@"numberOfSeats"] intValue]  - [_lastRideRequest[@"seats"] intValue] )];
        
        [driverStatus saveInBackground];
        
        
        [_dropOffButton setHidden:YES];
        [_dropOffPinImage setHidden:YES];
        
       
        assert(_rideRequests != nil);
        
        [self addChatHead: [_rideRequests indexOfObject:_lastRideRequest]];
        
         _lastRideRequest= nil;
        //
        //[self requestRouteToUser];
        
        
    }else{
        rideID = nil;
        
        driverStatus[@"inride"] = @NO;
        [driverStatus saveInBackground];
        
    }
    
}


-(void)didRequestForMessageBoardRideEnded:(NSNotification *)notification
{
    [self confirmedEndRideForMessageBoard];
    
}

-(void)confirmedEndRideForMessageBoard{
    
    
    isDriverAccepted = NO;
    
    [self.mapView removeOverlay:routeDetails.polyline];
    [mapView removeAnnotation:dropOffAnnotation];
    [self removeMessageBoardUsers];
    
    [endMessageBoardButton setHidden:YES];
    [endMessageBoardButton removeTarget:self action:@selector(endMessageBoard:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [startRideButton setTitle:@"CANCEL RIDE" forState:UIControlStateNormal];
    [startRideButton setHidden:YES];
    [startRideButton removeTarget:self action:@selector(addFirstNavPath:) forControlEvents:UIControlEventTouchUpInside];
    
    bottomLayoutConstrint.constant = 10;
    
    
    [userView setHidden:YES];
    
    [messageBoardUsersBGView setHidden:YES];
    
    [cancelRideButton setTitle:@"NAVIGATE" forState:UIControlStateNormal];
    [cancelRideButton removeTarget:self action:@selector(navigateToMessageBoard:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
}




#pragma mark - Routing

-(void)traceRouteToUser{
    
    
    CLGeocoder *locator = [[CLGeocoder alloc]init];
    
    double myLatitude = mapView.userLocation.location.coordinate.latitude;
    double myLongitude = mapView.userLocation.location.coordinate.longitude;
    
    pickUpCoord.latitude = myLatitude;
    pickUpCoord.longitude = myLongitude;
    
    
    dropOffCoord.latitude = userLat;
    dropOffCoord.longitude = userLong;
    
    
    
    CLLocation *location = [[CLLocation alloc]initWithLatitude:myLatitude longitude:myLongitude];
    
    [locator reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        pickupPlacemark = [placemarks objectAtIndex:0];
        
        CLGeocoder *locatorDrop = [[CLGeocoder alloc]init];
        
        CLLocation *locationDrop = [[CLLocation alloc]initWithLatitude:userLat longitude:userLong];
        
        [locatorDrop reverseGeocodeLocation:locationDrop completionHandler:^(NSArray *placemarks, NSError *error) {
            
            dropoffPlacemark = [placemarks objectAtIndex:0];
            
            dropOffAddress = [[dropoffPlacemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
            
            
            if (!dropOffAnnotation) {
                dropOffAnnotation = [[DropoffAnnotation alloc] initiWithTitle:dropOffAddress Location:dropOffCoord];
                
            }
            else{
                dropOffAnnotation.coordinate = dropOffCoord;
                dropOffAnnotation.title = dropOffAddress;
                
            }
            [mapView addAnnotation:dropOffAnnotation];
            [self addRouteToUser];
            
            
            
        }];
    }];
    
    
    
}

-(void)requestRouteToUser{
    
    
    
    
    startRideButton.hidden = NO;
    
    [startRideButton setTitle:@"NAVIGATE TO USER" forState:UIControlStateNormal];
    
    [startRideButton removeTarget:self action:@selector(startRide:) forControlEvents:UIControlEventTouchUpInside];
    
    [startRideButton addTarget:self action:@selector(navigateToUser:) forControlEvents:UIControlEventTouchUpInside];
    
    self.userView.hidden = NO;
    self.bottomLayoutConstrint.constant = 80;
    
    
    
}

-(void)addRouteToUser{
    
    
    [HUD showUIBlockingIndicatorWithText:@"Routing.."];
    
    MKDirectionsRequest *directionsRequest = [[MKDirectionsRequest alloc] init];
    MKPlacemark *dropPlacemark = [[MKPlacemark alloc] initWithPlacemark:dropoffPlacemark];
    MKPlacemark *pickPlacemark = [[MKPlacemark alloc] initWithPlacemark:pickupPlacemark];
    
    [directionsRequest setSource:[[MKMapItem alloc] initWithPlacemark:dropPlacemark]];
    [directionsRequest setDestination:[[MKMapItem alloc] initWithPlacemark:pickPlacemark]];
    directionsRequest.transportType = MKDirectionsTransportTypeAutomobile;
    
    MKDirections *directions = [[MKDirections alloc] initWithRequest:directionsRequest];
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        if (error) {
            NSLog(@"Error %@", error.description);
        }
        else{
            routeDetails = response.routes.lastObject;
            
            
            [self.mapView addOverlay:routeDetails.polyline];
            
            
            
            
            
        }
        [HUD hideUIBlockingIndicator];
    }];
    
}



-(void)showRouteOnMap{
    
    
    CLLocationCoordinate2D southWest = driverCoord  ;
    CLLocationCoordinate2D northEast = destinationCoord;
    
    southWest.latitude = MIN(southWest.latitude, driverCoord.latitude);
    southWest.longitude = MIN(southWest.longitude, driverCoord.longitude);
    
    northEast.latitude = MAX(northEast.latitude, destinationCoord.latitude);
    northEast.longitude = MAX(northEast.longitude, destinationCoord.longitude);
    
    CLLocation *locSouthWest = [[CLLocation alloc] initWithLatitude:southWest.latitude longitude:southWest.longitude];
    CLLocation *locNorthEast = [[CLLocation alloc] initWithLatitude:northEast.latitude longitude:northEast.longitude];
    
    // This is a diag distance (if you wanted tighter you could do NE-NW or NE-SE)
    CLLocationDistance meters = [locSouthWest distanceFromLocation:locNorthEast];
    
    
    
    MKCoordinateRegion regionRoute;
    regionRoute.center.latitude = (southWest.latitude + northEast.latitude) / 2.0;
    regionRoute.center.longitude = (southWest.longitude + northEast.longitude) / 2.0;
    regionRoute.span.latitudeDelta = meters / 81319.5;
    regionRoute.span.longitudeDelta = 0.0;
    
    [mapView setRegion:regionRoute animated:YES];
    
}
#pragma mark - Routing for The User Selected
// add route for the selected user
-(void)routedAnnotationsForUserSelected:(double)userPickLat long:(double)userPickLong{
    
    CLGeocoder *locator = [[CLGeocoder alloc]init];
    
    
    
    pickUpCoord.latitude = userPickLat;
    pickUpCoord.longitude = userPickLong;
    
    
    dropOffCoord.latitude = userLat;
    dropOffCoord.longitude = userLong;
    
    
    
    CLLocation *location = [[CLLocation alloc]initWithLatitude:userPickLat longitude:userPickLong];
    
    [locator reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        pickupPlacemark = [placemarks objectAtIndex:0];
        
        CLGeocoder *locatorDrop = [[CLGeocoder alloc]init];
        
        CLLocation *locationDrop = [[CLLocation alloc]initWithLatitude:userLat longitude:userLong];
        
        [locatorDrop reverseGeocodeLocation:locationDrop completionHandler:^(NSArray *placemarks, NSError *error) {
            dropoffPlacemark = [placemarks objectAtIndex:0];
            
            dropOffAddress = [[dropoffPlacemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
            
            
            if (!dropOffAnnotation) {
                dropOffAnnotation = [[DropoffAnnotation alloc] initiWithTitle:dropOffAddress Location:dropOffCoord];
                
            }
            else{
                dropOffAnnotation.coordinate = dropOffCoord;
                dropOffAnnotation.title = dropOffAddress;
                
            }
            [mapView addAnnotation:dropOffAnnotation];
            [self addRouteToUser];
            
            
        }];
    }];
    
    
    
}

#pragma mark - Ride End and Rating View


-(void)didRequestForRideEnd:(NSNotification *)notification
{
    
    rideEndArray = [notification object];
    NSString* rideCost = rideEndArray[0];
    
    double rideCostDouble = [rideCost doubleValue];
    
    requestRideDecisionPopupViewController = [[RideRequestDecisionViewController alloc] initWithNibName:@"RideRequestDecisionViewController" bundle:nil];
    
    NSString* decisionStr = [NSString stringWithFormat:@"Ride Cost: $%.2f",rideCostDouble];
    
    requestRideDecisionPopupViewController.decision = decisionStr;
    requestRideDecisionPopupViewController.isAccepted = NO;
    requestRideDecisionPopupViewController.openRatingView = YES;
    [requestRideDecisionPopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:requestRideDecisionPopupViewController animated:YES completion:nil];
    
    
}



-(void)didRequestForOpenRatinView:(NSNotification *)notification
{
    [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self
                                   selector: @selector(openRatingView:) userInfo: nil repeats: NO];
    
    
}


-(void)openRatingView:(id)sender{
    
    
    [self performSegueWithIdentifier:@"rateUser" sender:nil];
    
    
    
    
    
}

#pragma mark - Check on any Active Ride for user

-(void)checkForUserStatus{
    
#warning check for active ride
    
    
    
    

}

#pragma mark - Get Message Board Ride data

-(void)getMessageBoardData:(NSString*)ride message:(NSString*)messages{
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *token = [prefs stringForKey:@"token"];
    NSString *driverId = [prefs stringForKey:@"driverId"];
    
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [manager.requestSerializer setValue:token forHTTPHeaderField:@"tokenId"];
    
    NSString* URL = [NSString stringWithFormat:@"http://ec2-52-74-6-189.ap-southeast-1.compute.amazonaws.com:8080/getBoardRideData?requestRideId=%@",ride];
    
    [manager GET:URL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"Success: %@", responseObject);
        messageBoardDict = responseObject;
        
        
        
        NSString* message =responseObject[@"message"];
        NSString* driverIDFromData =responseObject[@"driverId"];
        
        
        if ([message isEqualToString:@"Data retrieved succesfully."]) {
            isDriverAccepted = YES;
            
            int driver = [driverId intValue];
            int compareDriver = [driverIDFromData intValue];
            
            if (driver == compareDriver) {
                
                
                [self activateMessageDriveMode:responseObject];
                //[self rideRequestDecisonMade:messages];
            }
            
            
            
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", [error localizedDescription]);
        
    }];
    
    
    
}




#pragma mark - Driver Location Update

/*!
 @abstract Save the driver location on server
 */
-(void)updateDriverLocation:(id)sender{
    
    
    if(driverLocation == nil){
        
        PFQuery * query = [PFQuery queryWithClassName:@"UserLocation"];
        [query  whereKey:@"user" equalTo:[PFUser currentUser]];
        
        
        
        [query getFirstObjectInBackgroundWithBlock:^(PFObject *object, NSError * error){
            
            if(!error){
                
                
                driverLocation = object;
                
                [self updateDriverLocation:nil];
            }else{
                NSLog(@"Can't save user location");
                //will keep triyng until it works
            }
            
        }];
    }else{
        
        PFGeoPoint *location = [PFGeoPoint geoPointWithLatitude:latitude  longitude:driverLong];
        if(userCity!= nil && userCity.length > 0){
            
             driverLocation[@"city"] = userCity;
        }else{
            NSLog(@"Failed to get user city");
        }
        if(location){
            driverLocation[@"location"] =  location;
            NSAssert(currentAddress != nil, @"Current address is nil");
           
            if(currentAddress.length == 0){
                currentAddress = @"Undeterminated";
            }
            
            driverLocation[@"locationAddress"] = currentAddress;

        }
        
        
        [driverLocation saveInBackground];
        
        
    }
    
    
    
}




#pragma mark - More, Center location and Call Driver Buttons

- (IBAction)callUser:(id)sender {
    
    NSString *phoneNumber = [@"telprompt://" stringByAppendingString:userPhone];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}


-(void)cancelFired:(id)sender{
    NSLog(@"Who call this?");
    
}



- (IBAction)centerOnUsersLocation:(id)sender {
    
    [self updateLocationBarOnUserLocation];
    [mapView setRegion:region animated:YES];
    
}


#pragma mark - Location Manager and Map Delegate

- (void)mapView:(MKMapView *)aMapView didUpdateUserLocation:(MKUserLocation *)aUserLocation {
    
    MKCoordinateSpan span;
    span.latitudeDelta = 0.005;
    span.longitudeDelta = 0.005;
    CLLocationCoordinate2D location;
    location.latitude = aUserLocation.coordinate.latitude;
    location.longitude = aUserLocation.coordinate.longitude;
    region.span = span;
    region.center = location;
    
    
     [self updateLocationBarOnUserLocation];
    
    
    NSLog(@"%f %f",location.latitude,location.longitude);
    
    
}

-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay {
    MKPolylineRenderer  * routeLineRenderer = [[MKPolylineRenderer alloc] initWithPolyline:routeDetails.polyline];
    routeLineRenderer.strokeColor = [UIColor redColor];
    routeLineRenderer.lineWidth = 5;
    return routeLineRenderer;
}




- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    
    CLLocation *location =  [locations lastObject];
    
    CLLocationCoordinate2D currentCoordinates = location.coordinate;
    latitude = currentCoordinates.latitude;
    driverLong = currentCoordinates.longitude;
    
    
    CLGeocoder *locator = [[CLGeocoder alloc]init];
    
    [locator reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        if(!error){
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            
            userCity = [placemark locality];
        }{
            NSLog(@"Can't update user city");
        }
        
    }];
    
    
}


#pragma mark - Annotation Views


-(MKAnnotationView*)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    if ([annotation isKindOfClass:[DropoffAnnotation class]]){
        DropoffAnnotation *dropoffAnnotation = (DropoffAnnotation*)annotation;
        MKAnnotationView *annotationView = [self.mapView dequeueReusableAnnotationViewWithIdentifier:@"DropoffAnnotation"];
        if (annotationView==nil) {
            annotationView = dropoffAnnotation.annotationView;
            
        }
        else
            annotationView.annotation = annotation;
        return annotationView;
    }
    
    if ([annotation isKindOfClass:[UserAnnotation class]]){
        UserAnnotation *dropoffAnnotation = (UserAnnotation*)annotation;
        MKAnnotationView *annotationView = [self.mapView dequeueReusableAnnotationViewWithIdentifier:@"UserAnnotation"];
        if (annotationView==nil) {
            annotationView = dropoffAnnotation.annotationView;
            
        }
        else
            annotationView.annotation = annotation;
        return annotationView;
    }
    
    else
        return nil;
    
}



#pragma mark - Location Bar Update (Must be removed)


-(void)updateUserLocationOnServer:(PFObject *) location{
    
    location[@"location"] = [PFGeoPoint geoPointWithLatitude:myLatitude longitude:myLongitude] ;
    
    [location saveInBackground];
    
    
    
    
}
-(void)updateLocationBarOnUserLocation{
    
//    NSLog(@"Updating my location as driver location");
    
    if(![driverStatus[@"active"] boolValue]  ){
        
        CLGeocoder *locator = [[CLGeocoder alloc]init];
        
        CLLocationCoordinate2D centerCoordinate = [mapView centerCoordinate];
        
        myLatitude = centerCoordinate.latitude;
        myLongitude = centerCoordinate.longitude;
        CLLocation *location = [[CLLocation alloc]initWithLatitude:myLatitude longitude:myLongitude];
        
        [locator reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
            if(!error){
                CLPlacemark *placemark = [placemarks objectAtIndex:0];
                
                
                NSDictionary * addressDictionary = placemark.addressDictionary;
                NSMutableArray *formatedAddressLines = [addressDictionary valueForKey:@"FormattedAddressLines"];
                [formatedAddressLines removeLastObject];
                [formatedAddressLines removeLastObject];
                
                currentAddress = [formatedAddressLines componentsJoinedByString:@", "];
                if(currentAddress.length !=0){
                    self.locationLabel.text = currentAddress;
                }else{
                    self.locationLabel.text = @"Updating location..";
                }
                
            }
            
            
            
        }];
        
    }
}



#pragma mark - Start of Ride (Not in use)

-(void)startRide:(id)sender{
    
    
    [self.mapView removeOverlay:routeDetails.polyline];
    [mapView removeAnnotation:dropOffAnnotation];
    
    userLat = destLat;
    userLong = destLong;
    
    [self requestRouteToUser];
    
    [startRideButton setTitle:@"NAVIGATE TO DESTINATION" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(startRide:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton addTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    calucaltateDistanceTimer =[NSTimer scheduledTimerWithTimeInterval:15.0
                                                               target:self
                                                             selector:@selector(calucaltateDistanceTimer:)
                                                             userInfo:nil
                                                              repeats:YES];
    

    
}




#pragma mark - Reject Ride Request (Not in use)

- (IBAction)rejectRideForUser:(id)sender {
    
    
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *token = [prefs stringForKey:@"token"];
        NSString *driverID = [prefs stringForKey:@"driverId"];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        int driverIDInt = [driverID intValue];
        
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        [manager setRequestSerializer:[AFHTTPRequestSerializer serializer]];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        [manager.requestSerializer setValue:token forHTTPHeaderField:@"tokenId"];
        
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        
        
        
        NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:rideID,@"rideId",nil];
        [params setValue:[NSNumber numberWithInt:driverIDInt] forKey:@"driverId"];
        
        NSString* URL_SIGNIN = @"http://ec2-52-74-6-189.ap-southeast-1.compute.amazonaws.com:8080/driverCancelRide";
        
        [manager POST:URL_SIGNIN parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"Success: %@", responseObject);
            
            NSString* message =responseObject[@"message"];
            
            if ([message isEqualToString:@"Ride cancelled."]) {
                
                isDriverAccepted = NO;
                
                [calucaltateDistanceTimer invalidate];
                calucaltateDistanceTimer = nil;
                
                [self.mapView removeOverlay:routeDetails.polyline];
                [mapView removeAnnotation:dropOffAnnotation];
                [startRideButton setHidden:YES];
                
                bottomLayoutConstrint.constant = 10;
                [userView setHidden:YES];
                
                
                
            }
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", [error localizedDescription]);
            
        }];
        
        
        
    });
    
    
}





#pragma mark - Ending of Ride (Not in use)


-(void)endRide:(id)sender{
    
    [self.mapView removeOverlay:routeDetails.polyline];
    
    [mapView removeAnnotation:dropOffAnnotation];
    
    [startRideButton setTitle:@"START NAVIGATION" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(endRide:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton setHidden:YES];
    
    bottomLayoutConstrint.constant = 10;
    [userView setHidden:YES];
    
    
    
    isDriverAccepted = NO;
    
    [calucaltateDistanceTimer invalidate];
    calucaltateDistanceTimer = nil;
    
    
    activeRide[@"finished"]= @YES;
    
    for(CHDraggableView *view in _chatHeads){
        [view removeFromSuperview];

        
    }
    
    [_chatHeads removeAllObjects];
    NSMutableArray* usersArray = [[NSMutableArray alloc]init];
    for (PFObject *ride in _rideRequests){
    
        ride[@"finished"] = @"YES";
        [usersArray addObject:ride[@"requestedBy"]];
        [ride saveEventually];
    }
    
    if( [(NSNumber*)driverStatus[@"inride"] boolValue] == YES){
        [self openRatingView:nil];
        
        //send push notifying user
        
        NSString * key = @"RIDE_ENDED";
        
        driverStatus[@"inride"] = @NO;
        [driverStatus saveInBackground];
        PFQuery *userQuery =[PFInstallation query];
        
        [userQuery whereKey:@"user" containedIn:usersArray];
        
        PFPush *push = [[PFPush alloc] init];
        
        [push setQuery:userQuery ];
        //TODO: here ride id is not valid any more, because will be many ride ids
        
        NSDictionary *data = @{
                               @"alert" : @"Hope you enjoyed your ride with Alfred\n, please leave feedback for your journey.",
                               @"driverID": [PFUser currentUser].objectId,
                               @"rid" : rideID,
                               @"key" : key,
                               @"badge": @"Increment"
                               };
        
        [push setData:data];
        
        
        [push sendPushInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
            if(succeeded){
                
                NSLog(@"Push for finishing ride succeeded");
                
                
                
            }
        }];
        
        
        
        
    }
    
    
    
    
    
    [activeRide saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        NSLog(@"Ride ended");
        
        
        
    }];
    
    
    driverStatus[@"inride"] = @NO;
    driverStatus[@"active"] = @NO;
    
    [driverStatus saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        if(succeeded){
            NSLog(@"Saved driver end ride successfully on parse");
        }
    }];
    
    
    
    
    [self cancelDropoff:nil];
    
    
    
}


#pragma mark - Ride Accepted or Rejected and Others(Not in use)



-(void)didRequestForRideAcceptedForDriver:(NSNotification *)notification
{
    requestRideDecisionPopupViewController = [[RideRequestDecisionViewController alloc] initWithNibName:@"RideRequestDecisionViewController" bundle:nil];
    
    requestRideDecisionPopupViewController.decision = @"You have been accepted as the driver";
    requestRideDecisionPopupViewController.isAccepted = YES;
    [requestRideDecisionPopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:requestRideDecisionPopupViewController animated:YES completion:nil];
    
    
    
}


-(void)didRequestForRideAcceptedByAnotherDriver:(NSNotification *)notification
{
    
    requestRideDecisionPopupViewController = [[RideRequestDecisionViewController alloc] initWithNibName:@"RideRequestDecisionViewController" bundle:nil];
    
    requestRideDecisionPopupViewController.decision = @"Sorry but another driver has been accepted for the ride";
    requestRideDecisionPopupViewController.isAccepted = NO;
    [requestRideDecisionPopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self presentViewController:requestRideDecisionPopupViewController animated:YES completion:nil];
    isDriverAccepted = NO;
    
}


-(void)calculateDistanceTimer:(id)sender{
    
    
    double myLatitude = mapView.userLocation.location.coordinate.latitude;
    double myLongitude = mapView.userLocation.location.coordinate.longitude;
    
    CLLocation *locA = [[CLLocation alloc] initWithLatitude:driverStartLat longitude:driverStartLong];
    
    CLLocation *locB = [[CLLocation alloc] initWithLatitude:myLatitude longitude:myLongitude];
    driverDistanceTravelled = [locA distanceFromLocation:locB];
    distanceCovered += driverDistanceTravelled;
    
    NSLog(@"Total distance being travelled: %f",distanceCovered);
    
    driverStartLat = myLatitude;
    driverStartLong = myLongitude;
    
}

-(void)navigateToDestination:(id)sender{
    

        
    [CMMapLauncher launchMapApp:CMMapAppAppleMaps
                    forDirectionsTo:[CMMapPoint mapPointWithName:@"Destination"
                                                      coordinate:destinationCoord]];
        
    
    NSLog(@"Driver is navigating to destination");
    
    [startRideButton setTitle:@"END RIDE" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton addTarget:self action:@selector(endRide:) forControlEvents:UIControlEventTouchUpInside];
    
}



-(void)navigateToUser:(id)sender{
    
    
    NSLog(@"Driver is navigating to user");
    
    
    
    BOOL googleInstalled = [CMMapLauncher isMapAppInstalled:CMMapAppGoogleMaps];
    
   
        
    [CMMapLauncher launchMapApp:CMMapAppAppleMaps forDirectionsTo:[CMMapPoint mapPointWithName:dropoffAddress address:dropoffAddress coordinate:dropOffCoord]];
        
        
    
    
    
    [startRideButton setTitle:@"NAVIGATE TO DESTINATION" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(navigateToUser:) forControlEvents:UIControlEventTouchUpInside];
    
    [startRideButton addTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSLog(@"User started navigation to user");
    
    
}

-(void)navigateToDestination{
    
    [startRideButton setTitle:@"NAVIGATE TO DESTINATION" forState:UIControlStateNormal];
    [startRideButton removeTarget:self action:@selector(navigateToUser:) forControlEvents:UIControlEventTouchUpInside];
    [startRideButton addTarget:self action:@selector(startRide:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)didRequestForRideRequestCancel:(NSNotification *)notification
{

    
    NSArray *data = [notification object];
    
    if ([data count] == 0){
        
    
    }
    
    
    
    NSString *rideId = [data firstObject];
    NSAssert(rideId != nil, @"Request for canceling an nil ride id");
    
    
    PFObject * _canceledRideRequest = nil;
    for(PFObject *rideRequest in _rideRequests){
    
        if ([rideRequest.objectId isEqualToString:rideID]){
            _canceledRideRequest = rideRequest;
            break;
        }
    }
    if(_canceledRideRequest == nil){
        
        NSLog(@"Got cancel from inactive ride request %@",rideID);
        
        //skip silently
        
        return;
    
    }
    
    PFUser *rider = _canceledRideRequest[@"requestedBy"];
    
    
    if (isDriverAccepted) {
        
        requestRideDecisionPopupViewController = [[RideRequestDecisionViewController alloc] initWithNibName:@"RideRequestDecisionViewController" bundle:nil];
        
        requestRideDecisionPopupViewController.decision = [NSString stringWithFormat:@"The ride was canceled by %@",rider[@"Full Name"]];

        requestRideDecisionPopupViewController.isAccepted = NO;
        [requestRideDecisionPopupViewController setModalPresentationStyle:UIModalPresentationOverCurrentContext];
        self.navigationController.modalPresentationStyle = UIModalPresentationCurrentContext;
        [self presentViewController:requestRideDecisionPopupViewController animated:YES completion:nil];
        
        isDriverAccepted = NO;
        
        [calucaltateDistanceTimer invalidate];
        calucaltateDistanceTimer = nil;
        
        //search for the index of the ride request
        int index = 0;
        
        for(PFObject* rideRequest in _rideRequests){
            
            if([rideRequest.objectId isEqualToString: rideId]){
                [rideRequest fetchIfNeeded];
                rideRequest[@"canceled"] = @YES;
                //TODO: get the number of seats requested and make the available again
                //this can be done in driverStatus
                
                [rideRequest saveInBackground];
                break;
            }
            index++;
            
        }
        //remove chat head with that index
        
        CHDraggableView *view =  [_chatHeads objectAtIndex:index];
        [view removeFromSuperview];
        [_chatHeads removeObjectAtIndex:index];
        //remove ride request from list
        
        [_rideRequests removeObjectAtIndex:index];

        
        if(_rideRequests.count == 0){
            
            driverStatus[@"inride"] = @NO;
            
        }
        driverStatus[@"available"] = @YES;
        
        [driverStatus saveInBackground];
        
        
        
        //change to navigate to destination
        
        
        NSAssert(_chatHeads.count == _rideRequests.count,@"Ride request count must be equal to the number of chatheads");
        
        
    }else{
        
        NSLog(@"Ride request canceled by driver");
    }
}

#pragma mark - Adjust Image Size
-(UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}


#pragma mark - Deallocation
-(void)viewDidDisappear:(BOOL)animated{
    [self.locationManager stopUpdatingLocation];
    
    [driverLocationTimer invalidate];
    driverLocationTimer = nil;
    [super viewDidDisappear:YES];
    
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForStoppingAllMappingServices" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideRequest" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideAcceptedForDriver" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideAcceptedByAnotherDriver" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideDecisionCloseView" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideRequestCancel" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForRideEnd" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForOpenRatinView" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForMessageBoardStartRide" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForMessageBoardStartAccepted" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForUserSelected" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForMessageBoardRideEnded" object:nil];
    
    
}

-(void)didRequestForStoppingAllMappingServices:(id)sender{
    [self.locationManager stopUpdatingLocation];
    
    [driverLocationTimer invalidate];
    driverLocationTimer = nil;
    [_mapCenterTimer invalidate];
    _mapCenterTimer = nil;
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)startRideButtonTouchUpInside:(id)sender {
    
    
    if(![[PFUser currentUser][@"PhoneVerified"] boolValue]){
        [[[UIAlertView alloc]initWithTitle:nil message:@"Please verify your phone number before advertising a ride" delegate:self cancelButtonTitle:@"Accept" otherButtonTitles:nil, nil] show];
        return;
        
    }
    
    NSLog(@"Start ride button clicked");
    NSLog(@"Ride details");
    
    if(!rideConfigured){
        
        
        [self performSegueWithIdentifier:@"RideSettingsSegue" sender:nil];
        
        
    }
    
    //    self.navigationItem.rightBarButtonItem=nil;
    
    
    //    driverStatus[@"inride"] = @YES;, not in ride, it is active but has no passenger
    
    //    [driverStatus saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
    //        if(succeeded){
    //            NSLog(@"Saved driver in ride successfully on parse");
    //        }
    //    }];
    
    //
    [self.startRideButton removeTarget:self action:@selector(startRideButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.startRideButton setTitle:@"NAVIGATE TO DESTINATION" forState: UIControlStateNormal];
    [self.startRideButton addTarget:self action:@selector(navigateToDestination:) forControlEvents:UIControlEventTouchUpInside];
    
 
    
    
    // [self traceRouteWithStartingCoordinates:pickUpCoord end:dropOffCoord];
    
    
    //make the driver active and advertise ride
    driverStatus[@"active"] = @YES;
    driverStatus[@"inride"] = @NO;
    driverStatus[@"available"] =  @YES;
    
    [driverStatus saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        if(succeeded){
            NSLog(@"Saved driver destination in parse");
            
        }
    }];
    
    #warning what happens now
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString: @"RideSettingsSegue"]){
        
        RideSettingsViewController *vc =(RideSettingsViewController*)[segue destinationViewController];
        vc.driverStatus = driverStatus;
    }
    if([segue.identifier isEqualToString: @"rateUser"]){
        
       RideRatingViewController *vc =(RideRatingViewController*)[segue destinationViewController];
        
        //rate only last user, this is wrong
        vc.rideRequest = [_rideRequests lastObject];
    }
    
}


#pragma mark DRIVER HEAD DELEGATE METHODS
-(void)didRequestForShowDropoffOnMap:(PFObject *)rideRequest{
    
    double dropoffLat  = [rideRequest[@"dropoffLat"] doubleValue];
    double dropoffLong  = [rideRequest[@"dropoffLong"] doubleValue];
    CLLocationCoordinate2D dropoffCoordinate = CLLocationCoordinate2DMake(dropoffLat, dropoffLong);
    self.mapView.centerCoordinate = dropoffCoordinate;
    
    
    
    
}
-(void)didRequestForShowPickupOnMap:(PFObject *)rideRequest{

    
    double pickupLat  = [rideRequest[@"pickupLat"] doubleValue];
    double pickupLong  = [rideRequest[@"pickupLong"] doubleValue];
    CLLocationCoordinate2D pickupCoordinate = CLLocationCoordinate2DMake(pickupLat, pickupLong);
    self.mapView.centerCoordinate = pickupCoordinate;
    
}
-(void)didRequestForRouteToPickup:(PFObject *)rideRequest{
    
    double pickupLat  = [rideRequest[@"pickupLat"] doubleValue];
    double pickupLong  = [rideRequest[@"pickupLong"] doubleValue];
    CLLocationCoordinate2D pickupCoordinate = CLLocationCoordinate2DMake(pickupLat, pickupLong);
    NSString *pickupAddress = rideRequest[@"pickupAddress"];
    
    
    [CMMapLauncher launchMapApp:CMMapAppAppleMaps
                forDirectionsTo:[CMMapPoint mapPointWithName:pickupAddress
                                                  coordinate:pickupCoordinate]];
    
    
    
    
    
}
-(void)didRequestForRouteToDropoff:(PFObject *)rideRequest{
    
    double dropoffLat  = [rideRequest[@"dropoffLat"] doubleValue];
    double dropoffLong  = [rideRequest[@"dropoffLong"] doubleValue];
    CLLocationCoordinate2D dropoffCoordinate = CLLocationCoordinate2DMake(dropoffLat, dropoffLong);
    NSString *dropoffAddress = rideRequest[@"dropoffAddress"];
    
    
    [CMMapLauncher launchMapApp:CMMapAppAppleMaps
                forDirectionsTo:[CMMapPoint mapPointWithName:dropoffAddress
                                                  coordinate:dropoffCoordinate]];


}
@end
