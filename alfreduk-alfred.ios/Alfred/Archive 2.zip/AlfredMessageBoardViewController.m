//
//  AlfredMessageBoardViewController.m
//  Alfred
//
//  Created by Miguel Angel Carvajal on 7/15/15.
//  Copyright (c) 2015 A Ascendanet Sun. All rights reserved.
//

#import "AlfredMessageBoardViewController.h"
#import "MessageBoardMessageTableViewCell.h"
#import "MessageBoardLogoTableViewCell.h"
#import "MessageBoardDriverDetailTableViewController.h"
#import "MessageBoardUserDetailTableViewController.h"
#import "MessageBoardPersonalUserTableViewController.h"
#import "MessageBoardPersonalDriverTableViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <Parse/Parse.h>
#import "AlfredMessage.h"

#import "SWRevealViewController.h"

@interface AlfredMessageBoardViewController () <UITabBarDelegate,UITableViewDataSource>

{
    NSArray *messageData;
    bool inDriverMode;
    
    BOOL myMessages;
    AlfredMessage  * selectedMessageDict;
    NSString * city;
    NSArray *_rideJoinRequests;
    NSArray *_userBoardMessages;
    
}
@end

@implementation AlfredMessageBoardViewController
@synthesize locationManager;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    messageData = [[NSArray alloc] init];
    
    //global messages
    
    myMessages = NO;
    //get from preferences
    inDriverMode = ![[PFUser currentUser][ @"UserMode"] boolValue];
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    
    //[self hideNavigationController];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    _rideJoinRequests = nil;
    _userBoardMessages =  nil;
    messageData = nil;
    
    if ( revealViewController ){
        [self.view addGestureRecognizer:revealViewController.panGestureRecognizer];
        
        
        [self.navigationItem.leftBarButtonItem setTarget:self.revealViewController];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    // [self fillLocalMessagesDataForDebugging];
    
    [self.segmentFilterControl addTarget:self action:@selector(filterChanged:) forControlEvents:UIControlEventValueChanged];
    
    
    self.navigationController.navigationItem.backBarButtonItem.title =  @"";
    
}
-(void)filterChanged:(id)sender{
    
    long index = self.segmentFilterControl.selectedSegmentIndex ;
    
    if(index ==  1 ){
        //load user request
        
        [self loadUserMessages];
        
    }else{
        [self loadCityMessages:city];
    }
}

-(void)loadCityMessages:(NSString*)city{
    
    
    
    PFQuery *query = [PFQuery queryWithClassName:@"BoardMessage"];
    
    //  [query whereKey:@"city" equalTo: city];
    [query includeKey:@"author"]; //load user data also
    if(inDriverMode){
        [query includeKey:@"author.userRating"];
        [query whereKey:@"driverMessage" equalTo:@NO];
    }else{
        [query includeKey:@"author.driverRating"];
        [query whereKey:@"driverMessage" equalTo:@YES];
    }
    
    
    
    // if user mode load driver messages
    [HUD showUIBlockingIndicatorWithText:@"Loading all messages"];
    
    [query  findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error){
        [HUD hideUIBlockingIndicator];
        if(!error){
            messageData = objects;
            
            if(objects.count == 0)
            {
                self.tableView.hidden = YES;
                return ;
            }
            else{
                
                self.tableView.hidden = NO;
                [self.tableView reloadData];
            }
            
        }else{
            
            if(error.code == 209){
                //TODO: Login user again
            
            }
            
            self.tableView.hidden = YES;
            messageData = nil;
            NSLog(@"Failed to get city messages");
        }
        
        
    }];
    
    
    
    
}
-(void)viewWillAppear:(BOOL)animated{
    
    
    UIImage *drawerImage = [[UIImage imageNamed:@"menu"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIBarButtonItem *revealButtonItem = [[UIBarButtonItem alloc] initWithImage:drawerImage
                                                                         style:UIBarButtonItemStylePlain target:self.revealViewController action:@selector(revealToggle:)];
    
    
    
    
    self.navigationItem.leftBarButtonItem = revealButtonItem;
    
    self.navigationItem.title = @"Message Board";
    
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:56.0f/255 green:169.0f/255 blue:180.0f/255 alpha:0.2f];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(postANewMessage:)];
    
    [super viewWillAppear:animated];
    
    if(!myMessages){
        if(!city){
            [self getTheUserCityAndMessages];
        }else{
            //this gets the current city and load the messages for the city
            [  self loadCityMessages:city];
        }
    }else{
        
        [self loadUserMessages];
    }
}

-(void)loadUserMessages{
    
    //this are the messages targeted to the user
    
    
    
    PFQuery *innerQuery = [    PFQuery queryWithClassName:@"BoardMessage"];
    [innerQuery whereKey:@"author" equalTo:[PFUser currentUser]];
    PFQuery *joinRequestQuery = [PFQuery queryWithClassName:@"JoinRideRequest"];
    [joinRequestQuery whereKey:@"boardMessage" matchesQuery:innerQuery];
    [joinRequestQuery includeKey:@"author"];
    [joinRequestQuery includeKey:@"author.userRating"];
    [joinRequestQuery findObjectsInBackgroundWithBlock:^(NSArray * _Nullable objects, NSError * _Nullable error) {
        if(!error){
            
            if(objects.count == 0)
            {
                self.tableView.hidden = YES;
                return ;
            }
            else{
                
                _rideJoinRequests = objects;
                [self.tableView reloadData];
                self.tableView.hidden = NO;
            }
            
        }
    }];
    
    
    
    
    
    PFQuery *query = [PFQuery queryWithClassName:@"BoardMessage"];
    [query whereKey:@"author" equalTo: [PFUser currentUser]];
    
    [query includeKey:@"author"];
    [query includeKey:@"author.driverRating"];
    [query includeKey:@"author.userRating"];
    
    [query  findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error){
        [HUD hideUIBlockingIndicator];
        if(!error){
            _userBoardMessages = objects;
            
            [self.tableView reloadData];
            
        }else{
            messageData = nil;
            NSLog(@"Failed to get user messages");
        }
        
    }];
    
    
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(self.segmentFilterControl.selectedSegmentIndex == 1){
        // all messages
        return 2;
        
    }else{
        //my messages
        
        return 1;
        
    }
    
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    if(self.segmentFilterControl.selectedSegmentIndex == 1){
        //my messages
        if(section == 0){
            return @"Ride join requests";
        }else if(section == 1){
            return @"Your booked rides";
        }
        return nil;
    }else{
        return nil;
    }
    
    
}

-(void)getTheUserCityAndMessages{
    
    [HUD showUIBlockingIndicatorWithText:@"Loading messages.." ];
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        [self.locationManager startUpdatingLocation];
        
        
    }
    
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init] ;
    [geocoder reverseGeocodeLocation:self.locationManager.location
                   completionHandler:^(NSArray *placemarks, NSError *error) {
                       
                       
                       NSLog(@"reverseGeocodeLocation:completionHandler: Completion Handler called!");
                       
                       if (error){
                           NSLog(@"Geocode failed with error: %@", error);
                           return;
                           
                       }
                       
                       else{
                           
                           CLPlacemark *placemark = [placemarks firstObject];
                           city = [placemark locality];
                           
                           [self loadCityMessages:city];
                           
                           NSLog(@"City: %@",city);
                           [self.locationManager stopUpdatingLocation];
                       }
                       
                   }];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(self.segmentFilterControl.selectedSegmentIndex == 1){
        if(section == 0){
            return _rideJoinRequests.count;
            
        }else{
            return _userBoardMessages.count;
        }
    }
    if(messageData){
        return [messageData count];
    }else{
        return 0;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
    
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(self.segmentFilterControl.selectedSegmentIndex == 0){
        
        
        if(indexPath.row < messageData.count){
            
            if(!inDriverMode){
                
                static NSString * cellIdentifier = @"RideOfferCell";
                
                MessageBoardMessageTableViewCell *cell = (MessageBoardMessageTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
                
                
                
                
                long row = indexPath.row;
                PFObject *message = messageData[indexPath.row];
                
                BOOL driver= [message[@"driverMessage"] boolValue];
                int seats = [message[@"seats"] intValue];
                
                //    int driver = [messageDict[@"driver"] intValue];
                NSString* dropAddress = message[@"dropoffAddress"];
                NSString* originAddress = message[@"pickupAddress"];
                double pricePerSeat = [message[@"pricePerSeat"] doubleValue];
                
                NSString* title = message[@"title"];
                
                NSString *date = message[@"date"];
                bool femaleOnly = [message[@"femaleOnly"] boolValue];
                
                
                PFUser *user = message[@"author"];
                
                NSString *pic = user[@"ProfilePicUrl"];
                NSString *firstName  = user[@"FirstName"];
                NSString *lastName = user[@"LastName"];
                NSString *userName = [NSString stringWithFormat:@"%@ %c.",firstName, [lastName characterAtIndex:0]];
                
                
                
                UILabel *priceLabel = (UILabel*) [cell viewWithTag:8];
                UILabel *seatsLabel = (UILabel*) [cell viewWithTag:7];
                UILabel *nameLabel = (UILabel*) [cell viewWithTag:4];
                UILabel *ratingLabel = (UILabel*) [cell viewWithTag:5];
                UILabel *titleLabel = (UILabel*) [cell viewWithTag:6];
                UILabel *dateLabel = (UILabel*) [cell viewWithTag:1];
                UILabel *ladiesOnlyLabel = (UILabel*) [cell viewWithTag:2];
                UIImageView *profilePicImageView =  (UIImageView*)[cell viewWithTag:3];
                UILabel *pickupLabel  = (UILabel*)[cell viewWithTag:20];
                UILabel *dropoffLabel = (UILabel*)[cell viewWithTag:21];
                
                
                dateLabel.text = date;
                
                nameLabel.text = userName;
                priceLabel.text = [NSString stringWithFormat:@"%.2lf £",pricePerSeat];
                seatsLabel.text = [NSString stringWithFormat:@"%2d",seats];
                titleLabel.text = title;
                pickupLabel.text = originAddress;
                dropoffLabel.text = dropAddress;
                
                
                if(femaleOnly){
                    ladiesOnlyLabel.hidden = NO;
                }else{
                    ladiesOnlyLabel.hidden = YES;
                }
                
                
                
                
                if (![pic isKindOfClass:[NSNull class]]) {
                    
                    [profilePicImageView sd_setImageWithURL:[NSURL URLWithString:pic] placeholderImage:[UIImage imageNamed:@"blank profile"]];
                }
                profilePicImageView.layer.cornerRadius = profilePicImageView.frame.size.height /2;
                profilePicImageView.layer.masksToBounds = YES;
                profilePicImageView.layer.borderWidth = 0;
                
                
                return cell;
            }
            else{
                
                //showing all messages and the user is in driver mode
                
                static NSString * cellIdentifier = @"RideRequestCell";
                
                MessageBoardMessageTableViewCell *cell = (MessageBoardMessageTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
                
                
                
                
                long row = indexPath.row;
                PFObject *message = messageData[indexPath.row];
                
                BOOL driver= [message[@"driverMessage"] boolValue];
                int seats = [message[@"seats"] integerValue];
                
                //    int driver = [messageDict[@"driver"] intValue];
                NSString* dropAddress = message[@"dropoffAddress"];
                NSString* originAddress = message[@"pickupAddress"];
                
                NSString* title = message[@"title"];
                
                NSString *date = message[@"date"];
                bool femaleOnly = [message[@"femaleOnly"] boolValue];
                
                
                PFUser *user = message[@"author"];
                
                NSString *pic = user[@"ProfilePicUrl"];
                NSString *firstName  = user[@"FirstName"];
                NSString *lastName = user[@"LastName"];
                NSString *userName = [NSString stringWithFormat:@"%@ %c.",firstName, [lastName characterAtIndex:0]];
                
                
                
                
                UILabel *seatsLabel = (UILabel*) [cell viewWithTag:7];
                UILabel *nameLabel = (UILabel*) [cell viewWithTag:4];
//                UILabel *ratingLabel = (UILabel*) [cell viewWithTag:5];
                UILabel *titleLabel = (UILabel*) [cell viewWithTag:6];
                UILabel *dateLabel = (UILabel*) [cell viewWithTag:1];
                UILabel *ladiesOnlyLabel = (UILabel*) [cell viewWithTag:2];
                UIImageView *profilePicImageView =  (UIImageView*)[cell viewWithTag:3];
                
                UILabel *pickupLabel = (UILabel*)[cell viewWithTag:20];
                UILabel *dropoffLabel = (UILabel*)[cell viewWithTag:21];
                
                pickupLabel.text = originAddress;
                dropoffLabel.text = dropAddress;

                
                dateLabel.text = date;
                
                nameLabel.text = userName;
                
                seatsLabel.text = [NSString stringWithFormat:@"%2d",seats];
                titleLabel.text = title;
                
                
                if(femaleOnly){
                    ladiesOnlyLabel.hidden = NO;
                }else{
                    ladiesOnlyLabel.hidden = YES;
                }
                
                
                
                
                if (![pic isKindOfClass:[NSNull class]]) {
                    
                    [profilePicImageView sd_setImageWithURL:[NSURL URLWithString:pic] placeholderImage:[UIImage imageNamed:@"blank profile"]];
                }
                profilePicImageView.layer.cornerRadius = profilePicImageView.frame.size.height /2;
                profilePicImageView.layer.masksToBounds = YES;
                profilePicImageView.layer.borderWidth = 0;
                
                
                return cell;
                
                
            }
            
            
        }
        
    }else{
        
        return [self tableView:tableView myMessagesCellForRowAtIndexPath:indexPath];
    }
    return nil;
    
}

//called to display cells for my messages section
-(UITableViewCell*)tableView:(UITableView*) tableView myMessagesCellForRowAtIndexPath:(NSIndexPath*)indexPath{
    
    if(indexPath.section == 0){
        //ride join request
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"RideJoinRequestCell"];
        UIImageView *profileImageView = [cell viewWithTag:3];
        UILabel *pickupAddressLabel = [cell viewWithTag:1];
        UILabel *dropoffAddressLabel = [cell viewWithTag:2];
        UILabel *nameLabel = [cell viewWithTag:4];
        UILabel *ratingLabel = [cell viewWithTag:5];
        UILabel *seatsLabel = [cell viewWithTag:7];
        PFObject *rideJoinRequest = [_rideJoinRequests objectAtIndex:indexPath.row];
        
        pickupAddressLabel.text =  rideJoinRequest[@"pickupAddress"];
        dropoffAddressLabel.text = rideJoinRequest[@"dropoffAddress"];
        PFUser * author = rideJoinRequest[@"author"];
        nameLabel.text = [NSString stringWithFormat:@"%@ %c", author[@"FirstName"] , [author[@"LastName"] characterAtIndex:0]];
        seatsLabel.text = [NSString stringWithFormat:@"%d", [rideJoinRequest[@"seats"] intValue] ];
        
        [profileImageView sd_setImageWithURL:[NSURL URLWithString:author[@"ProfilePicUrl"]] placeholderImage:[UIImage imageNamed:@"blank profile"]];
        
        return cell;
        
    }else if(indexPath.section == 1){
        static NSString * cellIdentifier = @"RideOfferCell";
        
        MessageBoardMessageTableViewCell *cell = (MessageBoardMessageTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        
        
        
        int row = indexPath.row;
        PFObject *message = _userBoardMessages[row];
        
        BOOL driver= [message[@"driverMessage"] boolValue];
        int seats = [message[@"seats"] integerValue];
        
        //    int driver = [messageDict[@"driver"] intValue];
        NSString* dropAddress = message[@"dropoffAddress"];
        NSString* originAddress = message[@"pickupAddress"];
        double pricePerSeat = [message[@"pricePerSeat"] doubleValue];
        NSString* title = message[@"title"];
        
        NSString *date = message[@"date"];
        bool femaleOnly = [message[@"femaleOnly"] boolValue];
        
        
        PFUser *user = message[@"author"];
        
        NSString *pic = user[@"ProfilePicUrl"];
        NSString *firstName  = user[@"FirstName"];
        NSString *lastName = user[@"LastName"];
        NSString *userName = [NSString stringWithFormat:@"%@ %c.",firstName, [lastName characterAtIndex:0]];
        
        
        
        UILabel *priceLabel = (UILabel*) [cell viewWithTag:8];
        UILabel *seatsLabel = (UILabel*) [cell viewWithTag:7];
        UILabel *nameLabel = (UILabel*) [cell viewWithTag:4];
        UILabel *ratingLabel = (UILabel*) [cell viewWithTag:5];
        UILabel *titleLabel = (UILabel*) [cell viewWithTag:6];
        UILabel *dateLabel = (UILabel*) [cell viewWithTag:1];
        UILabel *ladiesOnlyLabel = (UILabel*) [cell viewWithTag:2];
        UIImageView *profilePicImageView =  (UIImageView*)[cell viewWithTag:3];
        
        
        dateLabel.text = date;
        
        nameLabel.text = userName;
        priceLabel.text = [NSString stringWithFormat:@"£%3.2lf",pricePerSeat];
        seatsLabel.text = [NSString stringWithFormat:@"%2d",seats];
        titleLabel.text = title;
        
        
        if(femaleOnly){
            ladiesOnlyLabel.hidden = NO;
        }else{
            ladiesOnlyLabel.hidden = YES;
        }
        
        
        
        
        if (![pic isKindOfClass:[NSNull class]]) {
            
            [profilePicImageView sd_setImageWithURL:[NSURL URLWithString:pic] placeholderImage:[UIImage imageNamed:@"blank profile"]];
        }
        profilePicImageView.layer.cornerRadius = profilePicImageView.frame.size.height /2;
        profilePicImageView.layer.masksToBounds = YES;
        profilePicImageView.layer.borderWidth = 0;
        cell.layer.cornerRadius = 10;
        
        cell.layer.masksToBounds = YES;
        
        return cell;
        
        
    }
    return nil;
    
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    
    if ([[segue identifier] isEqualToString:@"MessageBoardPersonalDriverDetailSegueID"]){
        MessageBoardPersonalDriverTableViewController *vc = [segue destinationViewController];
        vc.selectedMessage = selectedMessageDict;
    }
    if ([[segue identifier] isEqualToString:@"MessageBoardPersonalUserDetailSegueID"]){
        MessageBoardPersonalUserTableViewController *vc = [segue destinationViewController];
        vc.selectedMessage = selectedMessageDict;
    }
    if ([[segue identifier] isEqualToString:@"MessageBoardDriverDetailSegueID"]){
        MessageBoardDriverDetailTableViewController *vc = [segue destinationViewController];
        vc.selectedMessage = selectedMessageDict;
    }
    if ([[segue identifier] isEqualToString:@"MessageBoardUserDetailSegueID"]){
        MessageBoardUserDetailTableViewController *vc = [segue destinationViewController];
        vc.selectedMessage = selectedMessageDict;
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    
    
    
    //        //filtered by user messages
    //        if (myMessages) {
    //            // the user is in driver mode
    //
    //            if (inDriverMode == YES) {
    //                [self performSegueWithIdentifier:@"MessageBoardPersonalDriverDetailSegueID" sender:self];
    //
    //            }
    //            //the user is not in driver mode
    //            else{
    //                [self performSegueWithIdentifier:@"MessageBoardPersonalUserDetailSegueID" sender:self];
    //
    //            }
    //
    //
    //        }
    //        else{
    if(self.segmentFilterControl.selectedSegmentIndex == 0){
        selectedMessageDict = messageData[indexPath.row];
        //this is fine
        if (inDriverMode == YES) {
            
            
            [self performSegueWithIdentifier:@"MessageBoardUserDetailSegueID" sender:self];
            
        }
        else{
            
            [self performSegueWithIdentifier:@"MessageBoardDriverDetailSegueID" sender:self];
            
        }
        
    }else{
        
        if(indexPath.section == 0){
            //this is for driver mode
            if(inDriverMode){
                selectedMessageDict = _rideJoinRequests[indexPath.row];
                
                [self performSegueWithIdentifier:@"MessageBoardUserDetailSegueID" sender:self];
            }
            else{
                //display request to take ride from alfreds
                
            }
            
        }else{
            //here should allow u to edit messages
            selectedMessageDict = _userBoardMessages[indexPath.row];
            //check message type
            bool driverMessage  = [selectedMessageDict[@"driverMessage"] boolValue];
            if(driverMessage){
                
                [self performSegueWithIdentifier:@"MessageBoardPersonalDriverDetailSegueID" sender:self];
            }
            else{
                [self performSegueWithIdentifier:@"MessageBoardPersonalUserDetailSegueID" sender:self];
                
            }
        }
    }
    //        }
    
}


- (IBAction)changeMessagesFilter:(id)sender {
    
    
    if(!myMessages){
        [_messagesFilterButton setTitle:@"ALL MESSAGES" forState:UIControlStateNormal];
        myMessages = YES;
        //load user messages
        [self loadUserMessages];
        [self.tableView reloadData];
        
    }else{
        myMessages = NO;
        [_messagesFilterButton setTitle:@"MY MESSAGES" forState:UIControlStateNormal];
        
        [self loadCityMessages:city];
        [self.tableView reloadData];
    }
}

- (IBAction)postANewMessage:(id)sender {
    
    //    if([[PFUser currentUser][@"UserMode"] boolValue]){
    //post a user message
    
    [self performSegueWithIdentifier:@"NewMessageSegueID" sender:self];
    //    }else{
    //        //post a driver message
    //        [[[UIAlertView alloc] initWithTitle:@"Feature not available" message:@"Sorry, right now u can't post messages a driver, you should be in passenger mode to book rides" delegate:nil cancelButtonTitle:@"Accept" otherButtonTitles:nil] show];
    //    }
    //    
    
}
@end
