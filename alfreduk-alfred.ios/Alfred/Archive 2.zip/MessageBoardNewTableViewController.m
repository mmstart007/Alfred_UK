//
//  MessageBoardNewTableViewController.m
//  Alfred
//
//  Created by Arjun Busani on 26/03/15.
//  Copyright (c) 2015 A Ascendanet Sun. All rights reserved.
//

#import "MessageBoardNewTableViewController.h"
#import "SWRevealViewController.h"
#import "MessageBoardNewLogoTableViewCell.h"
#import "MessageBoardNewMapTableViewCell.h"
#import "MessageBoardNewTitlesTableViewCell.h"
#import "MessageBoardNewMesssageTableViewCell.h"
#import "MessageBoardNewNumberOfSeatsTableViewCell.h"
#import "MessageBoardNewTimeTableViewCell.h"
#import "MessageBoardNewPriceTableViewCell.h"
#import "MessageBoardNewSendTableViewCell.h"
#import <Parse/Parse.h>
#import "AlfredMessage.h"


@interface MessageBoardNewTableViewController (){
    UILabel *priceLabel;
}

@end

@implementation MessageBoardNewTableViewController
@synthesize datePicker,postMessage,dateString;
@synthesize pickupButton,dropoffButton,pickLocationViewController,pickupAddress,dropoffAddress;
@synthesize titleTextField,seatsTextField,messageTextView,checkButton;
@synthesize onePountButton,twoPoundButton,threePoundButton,fourPoundButton;
@synthesize textFieldData;
@synthesize driverButton,userButton;
@synthesize pickLat,pickLong,dropLat,dropLong,city;


- (void)hideNavigationController {
    [self.navigationController.navigationBar setTranslucent:YES];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [[UIImage alloc] init];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    isItPick = true;
    price = 1;
    
    isItDriver = ![[PFUser currentUser][@"UserMode"] boolValue];
    
    
    if(!isItDriver){

       alphaForDriverButton = 0.5;
        
        alphaForUserButton = 1.;

    }
    else{
        alphaForUserButton = 0.5;
        alphaForDriverButton = 1.;
        
        
    }
    
    isPickupChecked = false;
    isDropoffChecked = false;
    
    id desiredColor = [UIColor whiteColor];
    self.tableView.backgroundColor = desiredColor;
    self.tableView.backgroundView.backgroundColor = desiredColor;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRequestForLocation:) name:@"didRequestForLocation" object:nil];

    
    //  self.tableView.backgroundView=[[UIImageView alloc] initWithImage:
    //                              [UIImage imageNamed:@"message_bg"]];
    

    
    pickupAddress = @"Pickup Location";
    dropoffAddress = @"Dropoff Location";

    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    checkButton.isChecked = NO;
    
    
    self.userButton.alpha = alphaForUserButton;
    self.driverButton.alpha = alphaForDriverButton;
    
    
   
    
    UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(backView:)];
    
    
    


    self.navigationItem.rightBarButtonItem = rightButton;
    self.navigationItem.title = @"New message";
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    textFieldData = [[NSMutableArray alloc]init];
    for (int i=0; i<3; i++)
    {
        [textFieldData addObject:@""];
    }
    
    [textFieldData replaceObjectAtIndex:1 withObject:@"Message"];


}


- (void)dealloc
{

    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"didRequestForLocation" object:nil];
    
    
    
}

-(void)didRequestForLocation:(NSNotification *)notification{
    NSMutableArray* locationArray = [notification object];
    
    if (isItPick) {
        
        
        pickLat = [locationArray[0] doubleValue];
        pickLong = [locationArray[1] doubleValue];
        city = locationArray[2];
        pickupAddress = locationArray[3];
        isPickupChecked = YES;
        
        [pickupButton setTitle:pickupAddress forState:UIControlStateNormal];
 
    }
    else{
        dropLat = [locationArray[0] doubleValue];
        dropLong = [locationArray[1] doubleValue];
        dropoffAddress = locationArray[3];
        isDropoffChecked = YES;
        [dropoffButton setTitle:dropoffAddress forState:UIControlStateNormal];
 
    }
}

/*! 
 @abstract Dimiss the view controller
*/
-(void)backView:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:nil]
    ;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 8;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    if (section==0) {
        return 1;
    }
    else if (section==1){
        return 1;

    }
    else if (section==2){
        return 1;
    }
    else if (section==3){
        return 1;
    }
    else if (section==4){
        return 1;
    }
    else if (section==5){
        return 1;
    }
    else if (section==6){
        return 1;
    }
    else if (section==7){
        return 2;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    
    
    
    static NSString *simpleTableIdentifier = @"MessageBoardNewLogoTableViewCell";
    //section 0 by default
    
    MessageBoardNewLogoTableViewCell *cell = (MessageBoardNewLogoTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewLogoTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }

    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    driverButton = cell.driverButton;
    driverButton.alpha = alphaForDriverButton;

    [driverButton addTarget:self action:@selector(driverButton:) forControlEvents:UIControlEventTouchUpInside];
    
    userButton = cell.userButton;
    userButton.alpha = alphaForUserButton;
    [userButton addTarget:self action:@selector(userButton:) forControlEvents:UIControlEventTouchUpInside];

    if ([indexPath section]==1) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewMapTableViewCell";
        MessageBoardNewMapTableViewCell *cell = (MessageBoardNewMapTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewMapTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        pickupButton = cell.pickupButton;
        [pickupButton setTitle:pickupAddress forState:UIControlStateNormal];

        [pickupButton addTarget:self action:@selector(pickupButton:) forControlEvents:UIControlEventTouchUpInside];
        dropoffButton = cell.dropoffButton;
        [dropoffButton setTitle:dropoffAddress forState:UIControlStateNormal];

        [dropoffButton addTarget:self action:@selector(dropoffButton:) forControlEvents:UIControlEventTouchUpInside];

        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }

    if ([indexPath section]==2) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewTitlesTableViewCell";
        MessageBoardNewTitlesTableViewCell *cell = (MessageBoardNewTitlesTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewTitlesTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleTextField.placeholder = @"Title";
        titleTextField = cell.titleTextField;
        cell.titleTextField.delegate = self;
        cell.titleTextField.tag = 10;
        cell.titleTextField.text = [textFieldData objectAtIndex:0];

        
        
        return cell;
    }
    
    
    if ([indexPath section]==3) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewMesssageTableViewCell";
        MessageBoardNewMesssageTableViewCell *cell = (MessageBoardNewMesssageTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewMesssageTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        messageTextView = cell.messageTextView;

        cell.messageTextView.delegate = self;
        cell.messageTextView.tag = 11;
        
        cell.messageTextView.text = [textFieldData objectAtIndex:1];
        
        
        if ([[textFieldData objectAtIndex:1] isEqualToString:@"Message"]) {
            cell.messageTextView.textColor = [UIColor lightGrayColor];
            
        }
        else{
            cell.messageTextView.textColor = [UIColor blackColor];
            
        }

        return cell;
    }
    if ([indexPath section]==4) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewNumberOfSeatsTableViewCell";
        MessageBoardNewNumberOfSeatsTableViewCell *cell = (MessageBoardNewNumberOfSeatsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewNumberOfSeatsTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        seatsTextField = cell.seatsTextField;
        cell.seatsTextField.delegate = self;
        cell.seatsTextField.tag = 12;
        cell.seatsTextField.text = [textFieldData objectAtIndex:2];
        
        checkButton = cell.femaleCheckButton;

        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    if ([indexPath section]==5) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewTimeTableViewCell";
        MessageBoardNewTimeTableViewCell *cell = (MessageBoardNewTimeTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewTimeTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        datePicker =  cell.datePicker;
                
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    if ([indexPath section]==6) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewPriceTableViewCell";
        MessageBoardNewPriceTableViewCell *cell = (MessageBoardNewPriceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewPriceTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        [cell.stepper addTarget:self action:@selector(ridePriceChanged:) forControlEvents:UIControlEventValueChanged];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        priceLabel = cell.priceLabel;
        price = cell.stepper.value;
        [priceLabel setText:[NSString stringWithFormat:@"%02d", price]];

        return cell;
    }

    
    if ([indexPath section]==7) {
        static NSString *simpleTableIdentifier = @"MessageBoardNewSendTableViewCell";
        MessageBoardNewSendTableViewCell *cell = (MessageBoardNewSendTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageBoardNewSendTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.row==0) {
          postMessage =   cell.postButton;
            [postMessage addTarget:self action:@selector(postMessage:) forControlEvents:UIControlEventTouchUpInside];
            
        }
        if (indexPath.row==1) {
            [cell.postButton setHidden:YES];
        }
        
        return cell;
    }

    return cell;
}

-(void)ridePriceChanged:(id)sender{
    
    UIStepper *stepper = (UIStepper*)sender;
     price = stepper.value;
    [priceLabel setText:[NSString stringWithFormat:@"%02d",price]];
   
}
-(void)userButton:(id)sender{
//    alphaForUserButton = 1;
//    alphaForDriverButton = 0.5;
//    userButton.alpha = 1;
//    driverButton.alpha = 0.5;
//    isItDriver = false;
// 
    

}

-(void)driverButton:(id)sender{
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    
    if(![prefs boolForKey:@"EnabledAsDriver"]) {
        
        alphaForUserButton = 0.5;
        alphaForDriverButton = 1;
      
        isItDriver = true;
        [self.tableView reloadData];
        
    }
  

}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    
    if (textField.tag == 10) {
        [textFieldData replaceObjectAtIndex:0 withObject:textField.text];
        
    }
    if (textField.tag == 12) {
        [textFieldData replaceObjectAtIndex:2 withObject:textField.text];
        
    }
   
    
}


#pragma mark - TextView delegate methods


-(void)textViewDidEndEditing:(UITextView *)textView{
    if (textView.tag == 11) {
        [textFieldData replaceObjectAtIndex:1 withObject:textView.text];
        
    }
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([[textView text] isEqualToString:@"Message"]) {
        [textFieldData replaceObjectAtIndex:1 withObject:@""];
        textView.text = [textFieldData objectAtIndex:1];
        textView.textColor = [UIColor blackColor];
    }
    
    return YES;
}

-(BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    if ([[textView text] length] == 0) {
        [textFieldData replaceObjectAtIndex:1 withObject:@"Message"];
        textView.text = [textFieldData objectAtIndex:1];
        textView.textColor = [UIColor lightGrayColor];
        
    }
    return YES;
}

#pragma mark - ui interactions


-(void)dropoffButton:(id)sender{
    
   
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    
    pickLocationViewController = [storyboard instantiateViewControllerWithIdentifier:@"PickLocationView"];
    
    
    
    
    pickLocationViewController.isPickup = NO;
    isItPick = NO;
  
    [self.navigationController pushViewController:pickLocationViewController animated:YES];
    
    
  
    
}

-(void)pickupButton:(id)sender{
    
   
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    
    pickLocationViewController = [storyboard instantiateViewControllerWithIdentifier:@"PickLocationView"];
    
    
    pickLocationViewController.isPickup = YES;
    
//    pickLocationViewController.isPickup = NO;
    isItPick = YES;
    
    [self.navigationController pushViewController:pickLocationViewController animated:YES];
    
 
    

}

/*!
 @abstract Post a new message to the message board, called when clicken on the button, post a message
 */

-(void)postMessage:(id)sender{
    
    if (titleTextField.text.length==0 || seatsTextField.text.length==0 || !isDropoffChecked || !isPickupChecked) {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Can't post message"
                                                                                 message:@"All fields required"
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        //We add buttons to the alert controller by creating UIAlertActions:
        UIAlertAction *actionOk = [UIAlertAction actionWithTitle:@"Accept"
                                                           style:UIAlertActionStyleDefault
                                                         handler:nil]; //You can use a block here to handle a press on this button
        [alertController addAction:actionOk];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    
    
    else{
        
        [HUD showUIBlockingIndicatorWithText:@"Please wait.."];
     
       
        PFObject *boardMessage = [PFObject objectWithClassName:@"BoardMessage"];
        boardMessage[@"pickupAddress"] =pickupAddress;
        boardMessage[@"dropoffAddress"] = dropoffAddress;
        boardMessage[@"title"]   = titleTextField.text;
        boardMessage[@"desc"] = messageTextView.text;
        boardMessage[@"seats" ] =  [NSNumber numberWithInt:[ seatsTextField.text intValue]];
        if(checkButton.isChecked){
            boardMessage[@"femaleOnly"] = @YES;
        }else{
            boardMessage[@"femaleOnly"] = @NO;
        }
        boardMessage[@"city"] = city;
        if(isItDriver){
            boardMessage[@"driverMessage"] = @YES;
        }else{
            boardMessage[@"driverMessage"] = @NO;
        }
        
        boardMessage[@"pricePerSeat"] = [NSNumber numberWithDouble:[priceLabel.text doubleValue]];

        

        boardMessage [@"pickupLat"]  = [NSNumber numberWithDouble:pickLat] ;
        boardMessage[@"pickupLong"]  = [NSNumber numberWithDouble:pickLong] ;
        boardMessage[@"dropoffLat"]= [NSNumber numberWithDouble:dropLat] ;
        boardMessage[@"dropoffLong"]= [NSNumber numberWithDouble:dropLong] ;

        NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"MM/dd/Y HH:mm:ss"];
        
        boardMessage[@"date"] = [formatter stringFromDate:datePicker.date];
        boardMessage[@"author"] = [PFUser currentUser];
        
        
        [boardMessage saveInBackgroundWithBlock:^(BOOL succeeded, NSError* error){
            if(error){
                NSLog(@"Failed to post new message");
                [[[UIAlertView alloc] initWithTitle:@"Message post failed" message:@"Check your network connection and try again." delegate:self cancelButtonTitle:@"Accept" otherButtonTitles:nil, nil] show];
            }else{
                
                NSLog(@"Message posted sucessfully");
                [self backView:self];
            
            }
        
             [HUD hideUIBlockingIndicator];
        }];
        
        
        

        // what happends after requesting a ride
        
        //[self dismissViewControllerAnimated:YES completion:nil];
        
    }

 
    

}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UIView * txt in self.view.subviews){
        if ([txt isKindOfClass:[UITextField class]] && [txt isFirstResponder]) {
            [txt resignFirstResponder];
        }
    }
}


#pragma mark  - Table view delegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath section]==0) {
        return 155;
    }
    else if ([indexPath section]==1){
        return 130;
    }
    else if ([indexPath section]==2){
        return 60;
    }
    else if ([indexPath section]==3){
        return 120;
    }
    else if ([indexPath section]==4){
        return 70;
    }
    else if ([indexPath section]==5){
        return 202;
    }
    else if ([indexPath section]==6){
        return 70;
    }
    else if ([indexPath section]==7){
        return 60;
    }
    else
        return 140;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
