//
//  ViewController.m
//  PTKPayment Example
//
//  Created by Alex MacCaw on 1/21/13.
//  Copyright (c) 2013 Stripe. All rights reserved.
//

#import "PaymentViewController.h"
#include "Stripe.h"
#import "HUD.h"
#import <Parse/Parse.h>

@interface PaymentViewController() <UITextFieldDelegate>
{
    BOOL validCard;
}
@property IBOutlet PTKView* paymentView;
@property (weak, nonatomic) IBOutlet UITextField *accountHolderTextField;
- (IBAction)cancel:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;
@property (weak, nonatomic) IBOutlet UITextField *holderTextField;

- (IBAction)saveCard:(id)sender;

@end


#pragma mark -

@implementation PaymentViewController

- (void)viewDidLoad
{
    validCard = NO;
    [super viewDidLoad];
    
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }

//    self.title = @"Change Card";
    
    _saveButton.enabled = NO;
    _saveButton.hidden = YES;
    _holderTextField.delegate = self;
   
    self.paymentView.delegate = self;
    
   
    [self.paymentView becomeFirstResponder];
}


- (void) paymentView:(PTKView *)paymentView withCard:(PTKCard *)card isValid:(BOOL)valid
{
    validCard = valid;
    
   _saveButton.enabled
    = valid && (_holderTextField.text.length > 5);
    _saveButton.hidden = !_saveButton.enabled;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    if(textField){
        [textField resignFirstResponder];

        if(validCard && textField.text.length > 5){
            _saveButton.enabled = YES;
            _saveButton.hidden = NO;
        }else{
            _saveButton.enabled = NO;
            _saveButton.hidden = YES;
        }
        
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{

    if(textField.text < 5){
        _saveButton.enabled = NO;
        _saveButton.hidden = YES;
    }
}
- (IBAction)saveCard:(id)sender
{
   
    __block STPCard *card = [[STPCard alloc] init];
    
    NSLog(@"Card last4: %@", card.last4);
    NSLog(@"Card expiry: %lu/%lu", (unsigned long)card.expMonth, (unsigned long)card.expYear);
    NSLog(@"Card cvc: %@", card.cvc);
    
    [[NSUserDefaults standardUserDefaults] setValue:card.last4 forKey:@"card.last4"];
    
    
    
    card.number = self.paymentView.card.number;
    card.expMonth = self.paymentView.card.expMonth;
    card.expYear = self.paymentView.card.expYear;
    card.cvc = self.paymentView.card.cvc;
    [HUD showUIBlockingIndicatorWithText:@"Adding card ..."];
    
    
    [[STPAPIClient sharedClient] createTokenWithCard:card
                                          completion:^(STPToken *token, NSError *error) {
                                              if (error) {
                                                  NSLog(@"Failed to add card");
                                                  
                                                  NSString * errorMsg = @"Unknown reason";
                                                  [[[UIAlertView alloc] initWithTitle:@"Failed to add card" message:@"" delegate:errorMsg cancelButtonTitle:@"Accept" otherButtonTitles:nil, nil] show ];
                                              } else {
                                                    //
                                                  PFObject *card = [[PFObject alloc] initWithClassName:@"Card"];
                                                  card[@"StripeToken"] = token.tokenId;
                                                  card[@"User"] = [PFUser currentUser];
                                                  card[@"Expiry"] = [NSString stringWithFormat:@"%lu/%lu", self.paymentView.card.expMonth, self.paymentView.card.expYear];
                                                  
                                                  card[@"LastFour"] = self.paymentView.card.last4;
                                                  
                                                  [card saveInBackground];
                                                   [self dismissViewControllerAnimated:YES completion:nil];
                                              }
                                              [HUD hideUIBlockingIndicator];
                                          }];
    
    
    
   
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UIView * txt in self.view.subviews){
        if ([txt isKindOfClass:[UITextField class]] && [txt isFirstResponder]) {
            [txt resignFirstResponder];
        }
    }
}

- (IBAction)cancel:(UIButton *)sender {
    NSLog(@"Add Card cancelled");
    [self.paymentView resignFirstResponder];

    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
