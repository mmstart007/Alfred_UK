//
//  RideSettingsViewController.m
//  Alfred
//
//  Created by Miguel Angel Carvajal on 9/23/15.
//  Copyright © 2015 A Ascendanet Sun. All rights reserved.
//

#import "RideSettingsViewController.h"
#import "HUD.h"
#import <SDWebImage/UIImageView+WebCache.h>

#define kOFFSET_FOR_KEYBOARD 80.0

@interface RideSettingsViewController (){
    CGSize keyboardSize;
}
@property (weak, nonatomic) IBOutlet UIView *saveButton;


@end

@implementation RideSettingsViewController
@synthesize driverStatus;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
 
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    
    
    
    
}
-(void) viewWillDisappear:(BOOL)animated{
    // unregister for keyboard notifications while not visible.
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];


}
-(void)viewDidAppear:(BOOL)animated{
    
       [self.availableSeats becomeFirstResponder];

}

-(void)keyboardWillShow:(NSNotification*)notification {
    
    keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    [self setViewMovedUp:YES];


}



//method to move the view up/down whenever the keyboard is shown/dismissed
-(void)setViewMovedUp:(BOOL)movedUp
{
   

    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) shake:(UIView*)view {
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
    
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    animation.duration = 0.6;
    animation.values = @[ @(-20), @(20), @(-20), @(20), @(-10), @(10), @(-5), @(5), @(0) ];
    [view.layer addAnimation:animation forKey:@"shake"];
    
}

- (IBAction)saveRideData:(id)sender {
    
    [HUD showUIBlockingIndicatorWithText:@"Saving.." withTimeout:5];
    [self.availableSeats setTextColor:[UIColor blackColor]];
    [self.pricePerSeat setTextColor:[UIColor blackColor]];
    NSString *numberOfSeats = self.availableSeats.text;
    
    NSString *pricePerSeat =  self.pricePerSeat.text;
    
    NSString* errorString = nil;
    if([numberOfSeats intValue] < 1){
        errorString = @"Invalid number of seats";
        [self.availableSeats setTextColor:[UIColor redColor]];
        [self shake:self.availableSeats];

        return;
        
    }
    
    
    
    
    else if (errorString == NULL && ([pricePerSeat doubleValue] < 1 || [pricePerSeat doubleValue] > 100)){
        errorString = @"Invalid price per seat";
        [self.pricePerSeat setTextColor:[UIColor redColor]];
        [self shake:self.pricePerSeat];
    }
    if(errorString == nil){
        
        self.driverStatus[@"numberOfSeats"] = [NSNumber numberWithInt:[numberOfSeats intValue]];
        self.driverStatus[@"pricePerSeat"]= [NSNumber numberWithDouble:[pricePerSeat doubleValue]];
        self.driverStatus[@"ladiesOnly"] = (self.ladiesOnly.isOn)?@YES:@NO;
        
        
         [self.driverStatus saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
            if(succeeded){
                
                NSLog(@"Driver data updated sucessfully");
                [self.navigationController popViewControllerAnimated:YES];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"didConfigureRide" object:nil];

            }else{
                [[[UIAlertView alloc]initWithTitle:@"Error" message:@"Sorry, can save the ride settings, please try again" delegate:self cancelButtonTitle:@"Accept" otherButtonTitles:nil, nil] show];
                NSLog(@"failed");
            }
                [ HUD hideUIBlockingIndicator];
        }];;
        
    }
    
    
}
@end
