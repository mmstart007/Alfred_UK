//
//  MessageBoardNewPriceTableViewCell.m
//  Alfred
//
//  Created by Arjun Busani on 27/03/15.
//  Copyright (c) 2015 A Ascendanet Sun. All rights reserved.
//

#import "MessageBoardNewPriceTableViewCell.h"

@implementation MessageBoardNewPriceTableViewCell



- (IBAction)changePrice:(id)sender {
    
    
    
}
@end
